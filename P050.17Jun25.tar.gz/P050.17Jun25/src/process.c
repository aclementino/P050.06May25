#include "process.h"
#include "randw.h"
#include "kdtree.h"

void processing_data(NetCDF *file, DataSegment *ds, process_func func)
{
    for (int i = 0; i < (ds->argc); i++)
    {
        if (file == NULL || file[i].var == NULL)
        {
            printf("Application(processing_data): No data in file %i.\n", (i + 1));
            return;
        }
    }

    func(file, ds); // Call the processing function
}

double monache_metric(Variable *var, DataSegment *ds, int forecast, int analog, int i)
{
    double sum = 0.0;

    switch (var->type)
    {
        MONACHE(NC_BYTE);
        MONACHE(NC_CHAR);
        MONACHE(NC_SHORT);
        MONACHE(NC_INT);
        MONACHE(NC_FLOAT);
        MONACHE(NC_DOUBLE);
        MONACHE(NC_UBYTE);
        MONACHE(NC_USHORT);
        MONACHE(NC_UINT);
        MONACHE(NC_INT64);
        MONACHE(NC_UINT64);
    }

    return isnan(sum) ? NAN : sqrt(sum);
}

double monache_metric_super_window(NetCDF *file, DataSegment *ds, int forecast, int analog, int i)
{
    double sum = 0.0;

    for (int f = 0; f < (ds->argc); f++) // Soma sobre séries temporais
    {
        switch (file[f].var[i].type)
        {
            MONACHESW(NC_BYTE);
            MONACHESW(NC_CHAR);
            MONACHESW(NC_SHORT);
            MONACHESW(NC_INT);
            MONACHESW(NC_FLOAT);
            MONACHESW(NC_DOUBLE);
            MONACHESW(NC_UBYTE);
            MONACHESW(NC_USHORT);
            MONACHESW(NC_UINT);
            MONACHESW(NC_INT64);
            MONACHESW(NC_UINT64);
        }
    }

    return isnan(sum) ? NAN : sqrt(sum);
    // return isnan(sum) ? NAN : sum;
}

// Function to compare distances for heap
int compare_closest_point_ord_const(const void *x, const void *y)
{
    ClosestPoint *point1 = (ClosestPoint *)x;
    ClosestPoint *point2 = (ClosestPoint *)y;

    if (point1->distance < point2->distance)
        return 1;
    if (point1->distance > point2->distance)
        return -1;
    return 0;
}

void recreate_data(NetCDF *file, DataSegment *ds, ClosestPoint *closest, int f_count, int n)
{
    int count = 0;
    unsigned int indice = f_count;
    double sum_values = 0;

    // Verifique se os ponteiros são válidos
    if (!file->var[n].data || !file->var[n].created_data)
    {
        fprintf(stderr, "Dados ou memória criada estão nulos para var[%d]\n", n);
        return;
    }

    // printf("IT: %i, ID: %i\t", f_count, indice);
    switch (file->var[n].type)
    {
        REC_DATA(NC_BYTE);
        REC_DATA(NC_CHAR);
        REC_DATA(NC_SHORT);
        REC_DATA(NC_INT);
        REC_DATA(NC_FLOAT);
        REC_DATA(NC_DOUBLE);
        REC_DATA(NC_UBYTE);
        REC_DATA(NC_USHORT);
        REC_DATA(NC_UINT);
        REC_DATA(NC_INT64);
        REC_DATA(NC_UINT64);
    }
    // printf("IT: %i, count: %i\t", f_count, count);
}

void calculate_rmse(NetCDF *file, DataSegment *ds, int n)
{
    double sum_error = 0;
    int count = 0, ii = 0;

    switch (file->var[n].type)
    {
        CALC_RMSE(NC_BYTE);
        CALC_RMSE(NC_CHAR);
        CALC_RMSE(NC_SHORT);
        CALC_RMSE(NC_INT);
        CALC_RMSE(NC_FLOAT);
        CALC_RMSE(NC_DOUBLE);
        CALC_RMSE(NC_UBYTE);
        CALC_RMSE(NC_USHORT);
        CALC_RMSE(NC_UINT);
        CALC_RMSE(NC_INT64);
        CALC_RMSE(NC_UINT64);
    }

    file->var[n].rmse = sqrt(sum_error / count);
}

void recreate_data_fixed(NetCDF *file, DataSegment *ds, ClosestPoint *closest,
                         int forecast_position, int n, int num_found)
{
    int count = 0;
    double sum_values = 0;

    // Verificar se os ponteiros são válidos
    if (!file->var[n].data || !file->var[n].created_data)
    {
        fprintf(stderr, "Dados ou memória criada estão nulos para var[%d]\n", n);
        return;
    }

    // Verificar se temos pontos encontrados
    if (num_found == 0)
    {
        // fprintf(stderr, "Nenhum ponto próximo encontrado para forecast %d\n", forecast_position);
        // Marcar como NaN ou usar valor padrão
        switch (file->var[n].type)
        {
        case NC_FLOAT:
            ((float *)file->var[n].created_data)[forecast_position] = NAN;
            break;
        case NC_DOUBLE:
            ((double *)file->var[n].created_data)[forecast_position] = NAN;
            break;
            // Adicionar outros tipos conforme necessário
        }
        return;
    }

    // Processar apenas os pontos válidos encontrados
    for (int i = 0; i < num_found; i++)
    {
        // Verificar se o índice está dentro dos limites
        if (closest[i].window_index < 0 || closest[i].window_index >= file->dim->len)
        {
            // fprintf(stderr, "Índice inválido em closest[%d].window_index: %d\n",
            //         i, closest[i].window_index);
            continue;
        }

        // Verificar se a distância é válida (não foi inicializada com lixo)
        if (isnan(closest[i].distance) || isinf(closest[i].distance))
        {
            // fprintf(stderr, "Distância inválida em closest[%d]: %f\n", i, closest[i].distance);
            continue;
        }

        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float value = ((float *)file->var[n].data)[closest[i].window_index];
            if (!isnan(value))
            {
                sum_values += (double)value;
                count++;
            }
            break;
        }
        case NC_DOUBLE:
        {
            double value = ((double *)file->var[n].data)[closest[i].window_index];
            if (!isnan(value))
            {
                sum_values += value;
                count++;
            }
            break;
        }
            // Adicionar outros tipos conforme necessário
        }
    }

    // Verificar se temos valores válidos para fazer a média
    if (count > 0)
    {
        double average = sum_values / count;
        switch (file->var[n].type)
        {
        case NC_FLOAT:
            ((float *)file->var[n].created_data)[forecast_position] = (float)average;
            break;
        case NC_DOUBLE:
            ((double *)file->var[n].created_data)[forecast_position] = average;
            break;
            // Adicionar outros tipos conforme necessário
        }

#ifdef DEBUG
        printf("Forecast %d: Reconstruído %.3f usando %d pontos válidos\n",
               forecast_position, average, count);
#endif
    }
    else
    {
        // Nenhum valor válido encontrado, marcar como NaN
        switch (file->var[n].type)
        {
        case NC_FLOAT:
            ((float *)file->var[n].created_data)[forecast_position] = NAN;
            break;
        case NC_DOUBLE:
            ((double *)file->var[n].created_data)[forecast_position] = NAN;
            break;
        }

        // fprintf(stderr, "Nenhum valor válido para reconstruir forecast %d\n", forecast_position);
    }
}

// SOLUÇÃO 2: Corrigir calculate_rmse para usar mapeamento correto
void calculate_rmse_fixed(NetCDF *file, DataSegment *ds, int n)
{
    double sum_error = 0;
    int count = 0;
    int created_index = 0; // Índice para os dados reconstruídos

    for (int i = ds->start_prediction; i <= ds->end_prediction; i++)
    {
        // Verificar se o valor original é válido
        bool original_valid = false;
        bool reconstructed_valid = false;
        double original_value = 0;
        double reconstructed_value = 0;

        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float orig = ((float *)file->var[n].data)[i];
            float recon = ((float *)file->var[n].created_data)[created_index];

            original_valid = !isnan(orig);
            reconstructed_valid = !isnan(recon);
            original_value = (double)orig;
            reconstructed_value = (double)recon;
            break;
        }
        case NC_DOUBLE:
        {
            double orig = ((double *)file->var[n].data)[i];
            double recon = ((double *)file->var[n].created_data)[created_index];

            original_valid = !isnan(orig);
            reconstructed_valid = !isnan(recon);
            original_value = orig;
            reconstructed_value = recon;
            break;
        }
        }

        // Só calcular erro se ambos os valores são válidos
        if (original_valid && reconstructed_valid)
        {
            double error = original_value - reconstructed_value;
            sum_error += error * error;
            count++;

#ifdef DEBUG
            printf("Posição %d: Original=%.3f, Reconstruído=%.3f, Erro²=%.6f\n",
                   i, original_value, reconstructed_value, error * error);
#endif
        }
        else
        {
#ifdef DEBUG
            printf("Posição %d: Pulando - Original válido: %s, Reconstruído válido: %s\n",
                   i, original_valid ? "sim" : "não", reconstructed_valid ? "sim" : "não");
#endif
        }

        created_index++; // Incrementar índice dos dados reconstruídos
    }

    if (count > 0)
    {
        file->var[n].rmse = sqrt(sum_error / count);
        // printf("RMSE calculado: %.6f (baseado em %d pontos válidos)\n", file->var[n].rmse, count);
    }
    else
    {
        file->var[n].rmse = NAN;
        printf("RMSE: NaN (nenhum ponto válido para comparação)\n");
    }
}

// SOLUÇÃO 3: Inicialização segura de ClosestPoint
ClosestPoint *allocate_closest_points_safe(int num_points)
{
    ClosestPoint *closest = (ClosestPoint *)calloc(num_points, sizeof(ClosestPoint));

    if (closest == NULL)
    {
        fprintf(stderr, "Erro: Falha na alocação de memória para ClosestPoint\n");
        return NULL;
    }

    // Inicializar com valores seguros
    for (int i = 0; i < num_points; i++)
    {
        closest[i].window_index = -1;   // Índice inválido
        closest[i].distance = INFINITY; // Distância infinita
    }

    return closest;
}

// SOLUÇÃO 4: Validação do processo completo
bool validate_reconstruction_process(NetCDF *file, DataSegment *ds, int n)
{
    // Verificar se a memória foi alocada
    if (!file->var[n].created_data)
    {
        fprintf(stderr, "Erro: created_data não foi alocado para variável %d\n", n);
        return false;
    }

    // Verificar se o tamanho está correto
    int expected_size = ds->end_prediction - ds->start_prediction + 1;
    // printf("Validação: Esperado %d pontos reconstruídos\n", expected_size);

    // Contar quantos valores foram realmente reconstruídos
    int valid_count = 0;
    int invalid_count = 0;

    for (int i = 0; i < expected_size; i++)
    {
        bool is_valid = false;

        switch (file->var[n].type)
        {
        case NC_FLOAT:
            is_valid = !isnan(((float *)file->var[n].created_data)[i]);
            break;
        case NC_DOUBLE:
            is_valid = !isnan(((double *)file->var[n].created_data)[i]);
            break;
        }

        if (is_valid)
        {
            valid_count++;
        }
        else
        {
            invalid_count++;
        }
    }

    // printf("Validação: %d valores válidos, %d inválidos\n", valid_count, invalid_count);
    return valid_count > 0;
}

/* Exhaustive is the same Brute Force(bf)*/
void exhaustive_processing_independent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    predicted_file = &file[0];
    predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window = true, f_is_valid_last_win = true;

            // printf("length: %i\n", length);

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            // !predicted_file->var[n].created_data ? printf("created_data é nulo...") : printf("segue o baile!!!\n");
            // printf("passou aqui!!!");

            f_is_valid_last_win = false;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                int flag_break;
                int count_test = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                if (f_is_valid_last_win)
                {
                    int j = ds->k * 2;
                    flag_break = 0;

                    switch (predictor_file->var[n].type)
                    {
                        F_IFNAN(NC_BYTE);
                        F_IFNAN(NC_CHAR);
                        F_IFNAN(NC_SHORT);
                        F_IFNAN(NC_INT);
                        F_IFNAN(NC_FLOAT);
                        F_IFNAN(NC_DOUBLE);
                        F_IFNAN(NC_UBYTE);
                        F_IFNAN(NC_USHORT);
                        F_IFNAN(NC_UINT);
                        F_IFNAN(NC_INT64);
                        F_IFNAN(NC_UINT64);
                    }

                    if (flag_break == -1)
                        break;
                }
                else
                {
                    flag_break = 1;

                    // Check if the window is valid
                    for (int j = 0; j < ds->win_size; j++)
                    {
                        switch (predictor_file->var[n].type)
                        {
                            F_IFNAN(NC_BYTE);
                            F_IFNAN(NC_CHAR);
                            F_IFNAN(NC_SHORT);
                            F_IFNAN(NC_INT);
                            F_IFNAN(NC_FLOAT);
                            F_IFNAN(NC_DOUBLE);
                            F_IFNAN(NC_UBYTE);
                            F_IFNAN(NC_USHORT);
                            F_IFNAN(NC_UINT);
                            F_IFNAN(NC_INT64);
                            F_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            break;
                    }
                }

                if (flag_break == -1)
                    continue;

                f_valid_count++;
                f_is_valid_last_win = true;

                /* ---------- Training period begins ---------- */

                bool a_is_valid_last_win, a_is_valid_window;
                int valid_count = 0;
                int analog = 0;
                int found = 0;

                a_is_valid_last_win = false;

                /**/
                for (analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    // printf("passou aqui: %i!!!\n", analog);
                    a_is_valid_window = true;

                    if (a_is_valid_last_win)
                    {
                        int j = ds->k * 2;
                        flag_break = 0;
                        switch (predictor_file->var[n].type)
                        {
                            A_IFNAN(NC_BYTE);
                            A_IFNAN(NC_CHAR);
                            A_IFNAN(NC_SHORT);
                            A_IFNAN(NC_INT);
                            A_IFNAN(NC_FLOAT);
                            A_IFNAN(NC_DOUBLE);
                            A_IFNAN(NC_UBYTE);
                            A_IFNAN(NC_USHORT);
                            A_IFNAN(NC_UINT);
                            A_IFNAN(NC_INT64);
                            A_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            continue;
                    }
                    else
                    {
                        flag_break = 1;
                        // Check if the window is valid
                        for (int j = 0; j < ds->win_size; j++)
                        {
                            switch (predictor_file->var[n].type)
                            {
                                A_IFNAN(NC_BYTE);
                                A_IFNAN(NC_CHAR);
                                A_IFNAN(NC_SHORT);
                                A_IFNAN(NC_INT);
                                A_IFNAN(NC_FLOAT);
                                A_IFNAN(NC_DOUBLE);
                                A_IFNAN(NC_UBYTE);
                                A_IFNAN(NC_USHORT);
                                A_IFNAN(NC_UINT);
                                A_IFNAN(NC_INT64);
                                A_IFNAN(NC_UINT64);
                            }

                            if (flag_break == -1)
                                break;
                        }
                    }

                    if (flag_break == -1)
                        continue;

                    // Calculate distance only for valid windows
                    if (a_is_valid_window)
                    {
                        double distance = monache_metric(&predictor_file->var[n],
                                                         ds,
                                                         forecast,
                                                         analog,
                                                         n);

                        if (!isnan((double)distance))
                        {
                            if (found < ds->num_Na)
                            {
                                closest[found].window_index = analog;
                                closest[found].distance = distance;
                                found++;
                                if (found == ds->num_Na)
                                    qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                            else if (distance < closest[0].distance)
                            {
                                closest[0].window_index = analog;
                                closest[0].distance = distance;
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                        }

                        a_is_valid_last_win = true;
                        valid_count++;
                        a_count++;
                    }
                }
                // printf("a_count total: %i\n", a_count);

                printf("------------------------------------------------------------------\n");
                printf("Position: %i\n", forecast);
                for (int i = 0; i < found; i++)
                {
                    printf("| P%i D: %.2f ", i, closest[i].distance);
                    // printf("| P%i D: %.2f ", i, ((float *)predictor_file->var[n].data)[closest[i].window_index]);
                }
                printf("\n");
                printf("------------------------------------------------------------------\n");

                recreate_data(predicted_file, ds, closest, f_count, n);

                free(closest);
                // // Sort distances
                // qsort(distances, valid_count, sizeof(WindowDistance), compare_distances);
                f_count++;
            }
            // printf("f_count: %i\n", f_count);
            // printf("a_count: %.2lf\n", (double)a_count / f_count);
            // printf("a_count total: %i\n", a_count);
        }
        calculate_rmse(predicted_file, ds, n);
        printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
    }
}

void exhaustive_processing_dependent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    predicted_file = &file[0];
    predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window = true, f_is_valid_last_win = true;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            f_is_valid_last_win = false;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                int flag_break;
                int count_test = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                if (f_is_valid_last_win)
                {
                    int j = ds->k * 2;
                    flag_break = 0;

                    switch (predictor_file->var[n].type)
                    {
                        F_IFNAN(NC_BYTE);
                        F_IFNAN(NC_CHAR);
                        F_IFNAN(NC_SHORT);
                        F_IFNAN(NC_INT);
                        F_IFNAN(NC_FLOAT);
                        F_IFNAN(NC_DOUBLE);
                        F_IFNAN(NC_UBYTE);
                        F_IFNAN(NC_USHORT);
                        F_IFNAN(NC_UINT);
                        F_IFNAN(NC_INT64);
                        F_IFNAN(NC_UINT64);
                    }

                    if (flag_break == -1)
                        break;
                }
                else
                {
                    flag_break = 1;

                    // Check if the window is valid
                    for (int j = 0; j < ds->win_size; j++)
                    {
                        switch (predictor_file->var[n].type)
                        {
                            F_IFNAN(NC_BYTE);
                            F_IFNAN(NC_CHAR);
                            F_IFNAN(NC_SHORT);
                            F_IFNAN(NC_INT);
                            F_IFNAN(NC_FLOAT);
                            F_IFNAN(NC_DOUBLE);
                            F_IFNAN(NC_UBYTE);
                            F_IFNAN(NC_USHORT);
                            F_IFNAN(NC_UINT);
                            F_IFNAN(NC_INT64);
                            F_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            break;
                    }
                }

                if (flag_break == -1)
                    continue;

                f_valid_count++;
                f_is_valid_last_win = true;

                /* ---------- Training period begins ---------- */

                bool a_is_valid_last_win, a_is_valid_window;
                int valid_count = 0;
                int analog = 0;
                int found = 0;

                a_is_valid_last_win = false;

                /**/
                for (analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    // printf("passou aqui: %i!!!\n", analog);
                    a_is_valid_window = true;

                    if (a_is_valid_last_win)
                    {
                        int j = ds->k * 2;
                        flag_break = 0;
                        switch (predictor_file->var[n].type)
                        {
                            A_IFNAN(NC_BYTE);
                            A_IFNAN(NC_CHAR);
                            A_IFNAN(NC_SHORT);
                            A_IFNAN(NC_INT);
                            A_IFNAN(NC_FLOAT);
                            A_IFNAN(NC_DOUBLE);
                            A_IFNAN(NC_UBYTE);
                            A_IFNAN(NC_USHORT);
                            A_IFNAN(NC_UINT);
                            A_IFNAN(NC_INT64);
                            A_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            continue;
                    }
                    else
                    {
                        flag_break = 1;
                        // Check if the window is valid
                        for (int j = 0; j < ds->win_size; j++)
                        {
                            switch (predictor_file->var[n].type)
                            {
                                A_IFNAN(NC_BYTE);
                                A_IFNAN(NC_CHAR);
                                A_IFNAN(NC_SHORT);
                                A_IFNAN(NC_INT);
                                A_IFNAN(NC_FLOAT);
                                A_IFNAN(NC_DOUBLE);
                                A_IFNAN(NC_UBYTE);
                                A_IFNAN(NC_USHORT);
                                A_IFNAN(NC_UINT);
                                A_IFNAN(NC_INT64);
                                A_IFNAN(NC_UINT64);
                            }

                            if (flag_break == -1)
                                break;
                        }
                    }

                    if (flag_break == -1)
                        continue;

                    // Calculate distance only for valid windows
                    if (a_is_valid_window)
                    {
                        double distance = monache_metric_super_window(predictor_file,
                                                                      ds,
                                                                      forecast,
                                                                      analog,
                                                                      n);

                        if (!isnan((double)distance))
                        {
                            if (found < ds->num_Na)
                            {
                                closest[found].window_index = analog;
                                closest[found].distance = distance;
                                found++;
                                if (found == ds->num_Na)
                                    qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                            else if (distance < closest[0].distance)
                            {
                                closest[0].window_index = analog;
                                closest[0].distance = distance;
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                        }

                        a_is_valid_last_win = true;
                        valid_count++;
                        a_count++;
                    }
                }

                // printf("------------------------------------------------------------------\n");
                // printf("Position: %i\n", forecast);
                // for (int i = 0; i < found; i++)
                // {
                //     printf("| P%i D: %.2f ", i, closest[i].distance);
                //     // printf("| P%i D: %.2f ", i, ((float *)predictor_file->var[n].data)[closest[i].window_index]);
                // }
                // printf("\n");
                // printf("------------------------------------------------------------------\n");

                recreate_data(predicted_file, ds, closest, f_count, n);

                free(closest);
                f_count++;
            }
            // printf("f_count: %i\n", f_count);
            // printf("a_count: %.2lf\n", (double)a_count / f_count);
            // printf("a_count total: %i\n", a_count);
        }
        calculate_rmse(predicted_file, ds, n);
        // printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
        printf("%.3lf,", predicted_file->var[n].rmse);
    }
}

void raw_exhaustive_processing_dependent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    predicted_file = &file[0];
    predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window = true, f_is_valid_last_win = true;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            f_is_valid_last_win = false;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                int count_test = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                /* ---------- Training period begins ---------- */
                int valid_count = 0;
                int analog = 0;
                int found = 0;

                for (analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    // Calculate distance only for valid windows
                    double distance = monache_metric_super_window(predictor_file,
                                                                  ds,
                                                                  forecast,
                                                                  analog,
                                                                  n);

                    if (!isnan((double)distance))
                    {
                        if (found < ds->num_Na)
                        {
                            closest[found].window_index = analog;
                            closest[found].distance = distance;
                            found++;
                            if (found == ds->num_Na)
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                        }
                        else if (distance < closest[0].distance)
                        {
                            closest[0].window_index = analog;
                            closest[0].distance = distance;
                            qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                        }
                    }

                    valid_count++;
                    a_count++;
                }
                // printf("a_count total: %i\n", a_count);

                if (found != 0)
                {
                    printf("------------------------------------------------------------------\n");
                    printf("Position: %i\n", forecast);
                    for (int i = 0; i < found; i++)
                    {
                        printf("| P%i D: %.2f ", i, closest[i].distance);
                        // printf("| P%i D: %.2f ", i, ((float *)predictor_file->var[n].data)[closest[i].window_index]);
                    }
                    printf("\n");
                    printf("------------------------------------------------------------------\n");
                    recreate_data(predicted_file, ds, closest, f_count, n);
                    f_count++;
                }

                free(closest);
            }
            // printf("f_count: %i\n", f_count);
            // printf("a_count: %.2lf\n", (double)a_count / f_count);
            // printf("a_count total: %i\n", a_count);
        }
        calculate_rmse(predicted_file, ds, n);
        printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
    }
}

void partial_processing_independent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    // Start measuring time
    struct timeval begin, end;
    long seconds = 0;
    long microseconds = 0;
    double elapsed = 0;

    predicted_file = &file[0];
    predictor_file = &file[1];

    // Create a node pool for efficient memory management across iterations
    NodePool *global_pool = create_node_pool();

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window, f_is_valid_last_win;
            int analog = 0;

            // Reset the node pool for this iteration
            reset_node_pool(global_pool);

            // Initialize variables for the balanced KD-tree approach
            int total_training_points = ds->end_training - ds->start_training + 1;
            int *training_indices = (int *)malloc(total_training_points * sizeof(int));
            int valid_training_points = 0;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                printf("Warning: Check partial_processing_dependent_3->ALLOCATE_MEMORY_REC_DATA.\n");
                break;
            }

            f_is_valid_last_win = false;

            // First collect valid training points with optimized type-specific validation
            for (analog = ds->start_training; analog <= ds->end_training; analog++)
            {
                bool is_valid = true;

                // Check if this training point is valid (not NaN)
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                {
                    float *data = (float *)predictor_file->var[n].data;
                    int window_offset = analog - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                case NC_DOUBLE:
                {
                    double *data = (double *)predictor_file->var[n].data;
                    int window_offset = analog - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                    // Add other types similarly
                }

                // If valid, add to our array of training indices
                if (is_valid)
                {
                    training_indices[valid_training_points] = analog;
                    valid_training_points++;
                    a_count++;
                }
            }

            // Build a balanced KD-tree from all valid training points at once
            KDTree *root = NULL;
            if (valid_training_points > 0)
            {
                // Use the build_balanced_kdtree function with node pool
                root = build_balanced_kdtree(training_indices, valid_training_points,
                                             &predictor_file->var[n], ds, 0, global_pool);
            }

            // Free the temporary array
            free(training_indices);

// Print tree diagnostics in debug mode only
#ifdef DEBUG
            if (is_kdtree_balanced(root))
                printf("The k-d tree is balanced.\n");
            else
                printf("The k-d tree is not balanced. Rebalancing...\n");

            diagnose_tree_balance(root);

            // Rebalance if needed
            if (!is_kdtree_balanced(root))
            {
                root = rebalance_kdtree(root, &predictor_file->var[n], ds);
                printf("Tree after rebalancing:\n");
                diagnose_tree_balance(root);
            }
#endif

            int count_kdtree = 0;
            gettimeofday(&begin, 0);

            // Pre-allocate memory for batch processing
            ClosestPoint **all_closest_points = NULL;
            int num_valid_forecasts = 0;
            int *valid_forecasts = NULL;

            // First pass: count valid forecast points
            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                bool is_valid = true;

                // Check if this forecast point is valid
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                {
                    float *data = (float *)predictor_file->var[n].data;
                    int window_offset = forecast - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                case NC_DOUBLE:
                {
                    double *data = (double *)predictor_file->var[n].data;
                    int window_offset = forecast - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                    // Add other types similarly
                }

                if (is_valid)
                    num_valid_forecasts++;
            }

            // Allocate memory for valid forecasts and closest points
            if (num_valid_forecasts > 0)
            {
                valid_forecasts = (int *)malloc(num_valid_forecasts * sizeof(int));
                all_closest_points = (ClosestPoint **)malloc(num_valid_forecasts * sizeof(ClosestPoint *));

                // Second pass: collect valid forecasts
                int valid_idx = 0;
                for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
                {
                    bool is_valid = true;

                    // Check if this forecast point is valid (same as above)
                    switch (predictor_file->var[n].type)
                    {
                    case NC_FLOAT:
                    {
                        float *data = (float *)predictor_file->var[n].data;
                        int window_offset = forecast - ds->k;

                        for (int j = 0; j < ds->win_size; j++)
                        {
                            if (isnan(data[window_offset + j]))
                            {
                                is_valid = false;
                                break;
                            }
                        }
                        break;
                    }
                    case NC_DOUBLE:
                    {
                        double *data = (double *)predictor_file->var[n].data;
                        int window_offset = forecast - ds->k;

                        for (int j = 0; j < ds->win_size; j++)
                        {
                            if (isnan(data[window_offset + j]))
                            {
                                is_valid = false;
                                break;
                            }
                        }
                        break;
                    }
                        // Add other types similarly
                    }

                    if (is_valid)
                    {
                        valid_forecasts[valid_idx] = forecast;
                        all_closest_points[valid_idx] = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));
                        valid_idx++;
                    }
                }

                // Batch process all valid forecasts
                if (valid_idx > 0)
                {
                    // Process in batches for better cache utilization
                    int batch_size = 100; // Adjust based on your system's cache size
                    for (int batch_start = 0; batch_start < valid_idx; batch_start += batch_size)
                    {
                        int batch_end = batch_start + batch_size;
                        if (batch_end > valid_idx)
                            batch_end = valid_idx;

                        for (int i = batch_start; i < batch_end; i++)
                        {
                            int found = 0;
                            int forecast = valid_forecasts[i];

                            // Initialize current best distance for early termination
                            ds->current_best_distance = INFINITY;

                            // Search for nearest neighbors using the balanced tree
                            // search_closest_points_super_window(root, predictor_file, ds,
                            //                                    all_closest_points[i], forecast, 0, n, &found);
                            search_closest_points(root, &predictor_file->var[n], ds,
                                                  all_closest_points[i], forecast, 0, &found);
                        }
                    }
                }

                // Process results and recreate data
                for (int i = 0; i < valid_idx; i++)
                {
                    recreate_data(predicted_file, ds, all_closest_points[i], f_count, n);
                    free(all_closest_points[i]);
                    f_count++;
                    count_kdtree++;
                }

                // Free allocated memory
                free(valid_forecasts);
                free(all_closest_points);
            }

            // printf("f_count: %d\n", f_count);

            gettimeofday(&end, 0);
            seconds = end.tv_sec - begin.tv_sec;
            microseconds = end.tv_usec - begin.tv_usec;
            elapsed = seconds + microseconds * 1e-6;
            // printf("Time measured - search_closest_points: %.3f seconds.\n", elapsed);
            printf("%.3f,", elapsed);

            // We don't need to deallocate the tree nodes individually
            // since they're managed by the node pool
            calculate_rmse(predicted_file, ds, n);
            // printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
            printf("%.3lf,", predicted_file->var[n].rmse);
        }
    }

    // Free the global node pool at the end
    free_node_pool(global_pool);
}

void partial_processing_independent_2(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    // Start measuring time
    struct timeval begin, end;
    long seconds = 0;
    long microseconds = 0;
    double elapsed = 0;

    predicted_file = &file[0];
    predictor_file = &file[1];

    // Create a node pool for efficient memory management across iterations
    NodePool *global_pool = create_node_pool();

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window, f_is_valid_last_win;
            int analog = 0;

            // Reset the node pool for this iteration
            reset_node_pool(global_pool);

            // Initialize variables for the balanced KD-tree approach
            int total_training_points = ds->end_training - ds->start_training + 1;
            int *training_indices = (int *)malloc(total_training_points * sizeof(int));
            int valid_training_points = 0;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                printf("Warning: Check partial_processing_dependent_3->ALLOCATE_MEMORY_REC_DATA.\n");
                break;
            }

            f_is_valid_last_win = false;

            // First collect valid training points with optimized type-specific validation
            for (analog = ds->start_training; analog <= ds->end_training; analog++)
            {
                bool is_valid = true;

                // Check if this training point is valid (not NaN)
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                {
                    float *data = (float *)predictor_file->var[n].data;
                    int window_offset = analog - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                case NC_DOUBLE:
                {
                    double *data = (double *)predictor_file->var[n].data;
                    int window_offset = analog - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                    // Add other types similarly
                }

                // If valid, add to our array of training indices
                if (is_valid)
                {
                    training_indices[valid_training_points] = analog;
                    valid_training_points++;
                    a_count++;
                }
            }

            // Build a balanced KD-tree from all valid training points at once
            KDTree *root = NULL;
            if (valid_training_points > 0)
            {
                // Use the build_balanced_kdtree function with node pool
                root = build_optimized_balanced_kdtree(training_indices, valid_training_points,
                                                       &predictor_file->var[n], ds, 0, global_pool);
            }

            // Free the temporary array
            free(training_indices);

// Print tree diagnostics in debug mode only
#ifdef DEBUG
            if (is_kdtree_balanced(root))
                printf("The k-d tree is balanced.\n");
            else
                printf("The k-d tree is not balanced. Rebalancing...\n");

            diagnose_tree_balance(root);

            // Rebalance if needed
            if (!is_kdtree_balanced(root))
            {
                root = rebalance_kdtree(root, &predictor_file->var[n], ds);
                printf("Tree after rebalancing:\n");
                diagnose_tree_balance(root);
            }
#endif

            int count_kdtree = 0;
            gettimeofday(&begin, 0);

            // Pre-allocate memory for batch processing
            ClosestPoint **all_closest_points = NULL;
            int num_valid_forecasts = 0;
            int *valid_forecasts = NULL;

            // First pass: count valid forecast points
            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                bool is_valid = true;

                // Check if this forecast point is valid
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                {
                    float *data = (float *)predictor_file->var[n].data;
                    int window_offset = forecast - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                case NC_DOUBLE:
                {
                    double *data = (double *)predictor_file->var[n].data;
                    int window_offset = forecast - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                    // Add other types similarly
                }

                if (is_valid)
                    num_valid_forecasts++;
            }

            // Allocate memory for valid forecasts and closest points
            if (num_valid_forecasts > 0)
            {
                valid_forecasts = (int *)malloc(num_valid_forecasts * sizeof(int));
                all_closest_points = (ClosestPoint **)malloc(num_valid_forecasts * sizeof(ClosestPoint *));

                // Second pass: collect valid forecasts
                int valid_idx = 0;
                for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
                {
                    bool is_valid = true;

                    // Check if this forecast point is valid (same as above)
                    switch (predictor_file->var[n].type)
                    {
                    case NC_FLOAT:
                    {
                        float *data = (float *)predictor_file->var[n].data;
                        int window_offset = forecast - ds->k;

                        for (int j = 0; j < ds->win_size; j++)
                        {
                            if (isnan(data[window_offset + j]))
                            {
                                is_valid = false;
                                break;
                            }
                        }
                        break;
                    }
                    case NC_DOUBLE:
                    {
                        double *data = (double *)predictor_file->var[n].data;
                        int window_offset = forecast - ds->k;

                        for (int j = 0; j < ds->win_size; j++)
                        {
                            if (isnan(data[window_offset + j]))
                            {
                                is_valid = false;
                                break;
                            }
                        }
                        break;
                    }
                        // Add other types similarly
                    }

                    if (is_valid)
                    {
                        valid_forecasts[valid_idx] = forecast;
                        all_closest_points[valid_idx] = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));
                        valid_idx++;
                    }
                }

                // Batch process all valid forecasts
                if (valid_idx > 0)
                {
                    // Process in batches for better cache utilization
                    int batch_size = 100; // Adjust based on your system's cache size
                    for (int batch_start = 0; batch_start < valid_idx; batch_start += batch_size)
                    {
                        int batch_end = batch_start + batch_size;
                        if (batch_end > valid_idx)
                            batch_end = valid_idx;

                        for (int i = batch_start; i < batch_end; i++)
                        {
                            int found = 0;
                            int forecast = valid_forecasts[i];

                            // Initialize current best distance for early termination
                            ds->current_best_distance = INFINITY;

                            // Search for nearest neighbors using the balanced tree
                            search_closest_points_optimized(root, &predictor_file->var[n], ds,
                                                            all_closest_points[i], forecast, 0, &found);
                        }
                    }
                }

                // Process results and recreate data
                for (int i = 0; i < valid_idx; i++)
                {
                    recreate_data(predicted_file, ds, all_closest_points[i], f_count, n);
                    free(all_closest_points[i]);
                    f_count++;
                    count_kdtree++;
                }

                // Free allocated memory
                free(valid_forecasts);
                free(all_closest_points);
            }

            // printf("f_count: %d\n", f_count);

            gettimeofday(&end, 0);
            seconds = end.tv_sec - begin.tv_sec;
            microseconds = end.tv_usec - begin.tv_usec;
            elapsed = seconds + microseconds * 1e-6;
            // printf("Time measured - search_closest_points: %.3f seconds.\n", elapsed);
            printf("%.3f,", elapsed);

            // We don't need to deallocate the tree nodes individually
            // since they're managed by the node pool
            calculate_rmse(predicted_file, ds, n);
            // printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
            printf("%.3lf,", predicted_file->var[n].rmse);
        }
    }

    // Free the global node pool at the end
    free_node_pool(global_pool);
}

void debug_index_mapping(NetCDF *file, DataSegment *ds, int n, const char *function_name)
{
    printf("\n=== DEBUG MAPEAMENTO DE ÍNDICES [%s] ===\n", function_name);
    printf("start_prediction: %d, end_prediction: %d\n", ds->start_prediction, ds->end_prediction);
    printf("win_size: %d, k: %d\n", ds->win_size, ds->k);

    int total_forecasts = ds->end_prediction - ds->start_prediction + 1;
    printf("Tamanho total esperado: %d forecasts\n", total_forecasts);

    printf("\nAnálise de Validade dos Forecasts:\n");
    printf("Forecast | Index Direto | Válido? | Janela [início-fim]\n");
    printf("---------|--------------|---------|-------------------\n");

    int valid_count = 0;
    int invalid_count = 0;

    for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
    {
        int direct_index = forecast - ds->start_prediction;
        int window_start = forecast - ds->k;
        int window_end = forecast + ds->k;

        // Verificar se forecast é válido (mesmo código das funções)
        bool is_valid = true;
        int invalid_position = -1;

        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float *data = (float *)file->var[n].data;
            for (int j = 0; j < ds->win_size; j++)
            {
                int pos = window_start + j;
                if (pos < 0 || pos >= file->dim->len || isnan(data[pos]))
                {
                    is_valid = false;
                    invalid_position = pos;
                    break;
                }
            }
            break;
        }
        case NC_DOUBLE:
        {
            double *data = (double *)file->var[n].data;
            for (int j = 0; j < ds->win_size; j++)
            {
                int pos = window_start + j;
                if (pos < 0 || pos >= file->dim->len || isnan(data[pos]))
                {
                    is_valid = false;
                    invalid_position = pos;
                    break;
                }
            }
            break;
        }
        }

        printf("%8d | %11d | %7s | [%d-%d]",
               forecast, direct_index, is_valid ? "Sim" : "Não", window_start, window_end);

        if (!is_valid && invalid_position >= 0)
        {
            printf(" ← Inválido na pos %d", invalid_position);
        }
        printf("\n");

        if (is_valid)
        {
            valid_count++;
        }
        else
        {
            invalid_count++;
        }
    }

    printf("\nResumo:\n");
    printf("- Total de forecasts: %d\n", total_forecasts);
    printf("- Forecasts válidos: %d\n", valid_count);
    printf("- Forecasts inválidos: %d\n", invalid_count);
    printf("- Porcentagem válida: %.2f%%\n", (float)valid_count / total_forecasts * 100);
}

void debug_created_data_content(NetCDF *file, DataSegment *ds, int n, const char *function_name)
{
    printf("\n=== DEBUG CONTEÚDO DOS DADOS CRIADOS [%s] ===\n", function_name);

    if (!file->var[n].created_data)
    {
        printf("❌ ERRO: created_data é NULL!\n");
        return;
    }

    int total_size = ds->end_prediction - ds->start_prediction + 1;
    printf("Tamanho do array created_data: %d\n", total_size);

    printf("\nConteúdo dos dados reconstruídos:\n");
    printf("Index | Forecast Pos | Valor Criado | Válido?\n");
    printf("------|--------------|--------------|--------\n");

    int valid_reconstructed = 0;
    int invalid_reconstructed = 0;

    for (int i = 0; i < total_size; i++)
    {
        int forecast_pos = ds->start_prediction + i;
        bool is_valid = false;
        double value = 0;

        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float val = ((float *)file->var[n].created_data)[i];
            is_valid = !isnan(val);
            value = (double)val;
            break;
        }
        case NC_DOUBLE:
        {
            double val = ((double *)file->var[n].created_data)[i];
            is_valid = !isnan(val);
            value = val;
            break;
        }
        }

        printf("%5d | %11d | %12.3f | %7s\n",
               i, forecast_pos, value, is_valid ? "Sim" : "Não");

        if (is_valid)
        {
            valid_reconstructed++;
        }
        else
        {
            invalid_reconstructed++;
        }
    }

    printf("\nResumo dos dados reconstruídos:\n");
    printf("- Valores válidos: %d\n", valid_reconstructed);
    printf("- Valores inválidos (NaN): %d\n", invalid_reconstructed);
    printf("- Porcentagem reconstruída: %.2f%%\n", (float)valid_reconstructed / total_size * 100);
}

void debug_rmse_calculation(NetCDF *file, DataSegment *ds, int n, const char *function_name)
{
    printf("\n=== DEBUG CÁLCULO RMSE [%s] ===\n", function_name);

    printf("Comparação Valor Original vs Valor Reconstruído:\n");
    printf("Forecast | Index | Original | Reconstruído | Erro | Erro² | Usado?\n");
    printf("---------|-------|----------|--------------|------|-------|-------\n");

    double sum_error = 0;
    int count_used = 0;
    int count_skipped_original = 0;
    int count_skipped_reconstructed = 0;
    int count_skipped_forecast_invalid = 0;

    for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
    {
        int index = forecast - ds->start_prediction;

        // Verificar se o forecast era válido para processamento
        bool forecast_was_valid = true;
        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float *data = (float *)file->var[n].data;
            for (int j = 0; j < ds->win_size; j++)
            {
                if (isnan(data[(forecast - ds->k) + j]))
                {
                    forecast_was_valid = false;
                    break;
                }
            }
            break;
        }
        }

        // Verificar valor original
        bool original_valid = false;
        double original_value = 0;
        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float orig = ((float *)file->var[n].data)[forecast];
            original_valid = !isnan(orig);
            original_value = (double)orig;
            break;
        }
        case NC_DOUBLE:
        {
            double orig = ((double *)file->var[n].data)[forecast];
            original_valid = !isnan(orig);
            original_value = orig;
            break;
        }
        }

        // Verificar valor reconstruído
        bool reconstructed_valid = false;
        double reconstructed_value = 0;
        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float recon = ((float *)file->var[n].created_data)[index];
            reconstructed_valid = !isnan(recon);
            reconstructed_value = (double)recon;
            break;
        }
        case NC_DOUBLE:
        {
            double recon = ((double *)file->var[n].created_data)[index];
            reconstructed_valid = !isnan(recon);
            reconstructed_value = recon;
            break;
        }
        }

        double error = 0;
        double error_squared = 0;
        bool used_for_rmse = false;
        const char *skip_reason = "";

        if (!forecast_was_valid)
        {
            skip_reason = "Forecast inválido";
            count_skipped_forecast_invalid++;
        }
        else if (!original_valid)
        {
            skip_reason = "Original NaN";
            count_skipped_original++;
        }
        else if (!reconstructed_valid)
        {
            skip_reason = "Reconstruído NaN";
            count_skipped_reconstructed++;
        }
        else
        {
            error = original_value - reconstructed_value;
            error_squared = error * error;
            sum_error += error_squared;
            count_used++;
            used_for_rmse = true;
            skip_reason = "Usado";
        }

        printf("%8d | %5d | %8.3f | %12.3f | %4.3f | %5.6f | %s\n",
               forecast, index, original_value, reconstructed_value,
               error, error_squared, skip_reason);
    }

    printf("\nEstatísticas do RMSE:\n");
    printf("- Pontos usados para RMSE: %d\n", count_used);
    printf("- Pulados (forecast inválido): %d\n", count_skipped_forecast_invalid);
    printf("- Pulados (original NaN): %d\n", count_skipped_original);
    printf("- Pulados (reconstruído NaN): %d\n", count_skipped_reconstructed);
    printf("- Soma dos erros²: %.6f\n", sum_error);

    if (count_used > 0)
    {
        double rmse = sqrt(sum_error / count_used);
        printf("- RMSE calculado: %.6f\n", rmse);
    }
    else
    {
        printf("- RMSE: NaN (nenhum ponto válido)\n");
    }
}

// ========== FUNÇÃO PRINCIPAL DE DIAGNÓSTICO COMPLETO ==========
void run_complete_diagnostic(NetCDF *file, DataSegment *ds, int n, const char *function_name)
{
    printf("\n");
    printf("########################################################\n");
    printf("# DIAGNÓSTICO COMPLETO - %s\n", function_name);
    printf("# Variável: %d, Nome: %s\n", n, file->var[n].name);
    printf("########################################################\n");

    // 1. Analisar mapeamento de índices
    debug_index_mapping(file, ds, n, function_name);

    // 2. Analisar conteúdo dos dados criados
    debug_created_data_content(file, ds, n, function_name);

    // 3. Analisar cálculo do RMSE
    debug_rmse_calculation(file, ds, n, function_name);

    printf("\n########################################################\n");
    printf("# FIM DO DIAGNÓSTICO - %s\n", function_name);
    printf("########################################################\n\n");
}

// ========== FUNÇÕES AUXILIARES DE VALIDAÇÃO ==========

bool is_window_valid(Variable *var, int center_position, int k, int win_size, int data_length)
{
    int window_start = center_position - k;

    switch (var->type)
    {
    case NC_FLOAT:
    {
        float *data = (float *)var->data;
        for (int j = 0; j < win_size; j++)
        {
            int pos = window_start + j;
            if (pos < 0 || pos >= data_length || isnan(data[pos]))
            {
                return false;
            }
        }
        break;
    }
    case NC_DOUBLE:
    {
        double *data = (double *)var->data;
        for (int j = 0; j < win_size; j++)
        {
            int pos = window_start + j;
            if (pos < 0 || pos >= data_length || isnan(data[pos]))
            {
                return false;
            }
        }
        break;
    }
    // Adicionar outros tipos conforme necessário
    default:
        return false;
    }

    return true;
}

// ========== EXHAUSTIVE OTIMIZADO COM VALIDAÇÃO ==========

void exhaustive_processing_dependent_fixed(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    NetCDF *predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_count = 0;
            int a_count = 0;
            unsigned int length = (ds->end_prediction - ds->start_prediction) + 1;

            // Alocar memória para dados reconstruídos
            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            if (!predicted_file->var[n].created_data)
                continue;

            // Inicializar com NaN
            for (int i = 0; i < length; i++)
            {
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                case NC_DOUBLE:
                    ((double *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                }
            }

            // Processar cada forecast
            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                // Validar janela do forecast
                if (!is_window_valid(&predictor_file->var[n], forecast, ds->k,
                                     ds->win_size, predictor_file->dim->len))
                {
                    continue; // Pular forecast inválido
                }

                ClosestPoint *closest = allocate_closest_points_safe(ds->num_Na);
                if (!closest)
                    continue;

                int found = 0;

                // Buscar analogs válidos
                for (int analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    // Validar janela do analog
                    if (!is_window_valid(&predictor_file->var[n], analog, ds->k,
                                         ds->win_size, predictor_file->dim->len))
                    {
                        continue; // Pular analog inválido
                    }

                    // Calcular distância
                    double distance = monache_metric_super_window(predictor_file, ds,
                                                                  forecast, analog, n);

                    if (!isnan(distance))
                    {
                        if (found < ds->num_Na)
                        {
                            closest[found].window_index = analog;
                            closest[found].distance = distance;
                            found++;
                            if (found == ds->num_Na)
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint),
                                      compare_closest_point_ord_const);
                        }
                        else if (distance < closest[0].distance)
                        {
                            closest[0].window_index = analog;
                            closest[0].distance = distance;
                            qsort(closest, ds->num_Na, sizeof(ClosestPoint),
                                  compare_closest_point_ord_const);
                        }
                    }
                    a_count++;
                }

                // Reconstruir dados
                int created_data_index = forecast - ds->start_prediction;
                recreate_data_fixed(predicted_file, ds, closest, created_data_index, n, found);

                free(closest);
                f_count++;
            }
        }

        // Calcular RMSE
        if (validate_reconstruction_process(predicted_file, ds, n))
        {
            calculate_rmse_fixed(predicted_file, ds, n);
            // run_complete_diagnostic(predicted_file, ds, n, "EXHAUSTIVE_WITH_VALIDATION_OPTIMIZED");
        }
        else
        {
            predicted_file->var[n].rmse = NAN;
        }

        printf("%.3lf,", predicted_file->var[n].rmse);
    }
}

// ========== PARTIAL OTIMIZADO ==========

void partial_processing_independent_fixed(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    NetCDF *predictor_file = &file[1];

    // Start measuring time
    struct timeval begin, end;
    long seconds = 0;
    long microseconds = 0;
    double elapsed = 0;

    // Create a node pool for efficient memory management across iterations
    NodePool *global_pool = create_node_pool();

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_count = 0;
            int a_count = 0;
            unsigned int length = (ds->end_prediction - ds->start_prediction) + 1;

            // Reset the node pool for this iteration
            reset_node_pool(global_pool);

            // Initialize variables for the balanced KD-tree approach
            int total_training_points = ds->end_training - ds->start_training + 1;
            int *training_indices = (int *)malloc(total_training_points * sizeof(int));
            int valid_training_points = 0;

            // Alocar memória para dados reconstruídos
            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                printf("Warning: Check partial_processing_independent_fixed_optimized->ALLOCATE_MEMORY_REC_DATA.\n");
                break;
            }

            // Verificar se alocação foi bem-sucedida
            if (!predicted_file->var[n].created_data)
            {
                fprintf(stderr, "Erro: Falha na alocação de created_data para variável %d\n", n);
                free(training_indices);
                continue;
            }

            // Inicializar created_data com NaN
            for (int i = 0; i < length; i++)
            {
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                case NC_DOUBLE:
                    ((double *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                    // Adicionar outros tipos conforme necessário
                }
            }

            // ========== COLETA DE ANALOGS VÁLIDOS ==========
            // Usar a função auxiliar para validação consistente
            for (int analog = ds->start_training; analog <= ds->end_training; analog++)
            {
                // Validar janela do analog usando função auxiliar
                if (is_window_valid(&predictor_file->var[n], analog, ds->k,
                                    ds->win_size, predictor_file->dim->len))
                {
                    training_indices[valid_training_points] = analog;
                    valid_training_points++;
                    a_count++;
                }
            }

            // ========== CONSTRUÇÃO DA ÁRVORE KD ==========
            KDTree *root = NULL;
            if (valid_training_points > 0)
            {
                // Use the build_balanced_kdtree function with node pool
                root = build_balanced_kdtree(training_indices, valid_training_points,
                                             &predictor_file->var[n], ds, 0, global_pool);
            }

            // Free the temporary array
            free(training_indices);

            // ========== PROCESSAMENTO DOS FORECASTS ==========
            gettimeofday(&begin, 0);

            // Estruturas para coleta de forecasts válidos
            int *valid_forecasts = NULL;
            int num_valid_forecasts = 0;

            // Primeiro passo: contar forecasts válidos usando função auxiliar
            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                if (is_window_valid(&predictor_file->var[n], forecast, ds->k,
                                    ds->win_size, predictor_file->dim->len))
                {
                    num_valid_forecasts++;
                }
            }

            // Alocar e processar forecasts válidos
            if (num_valid_forecasts > 0)
            {
                valid_forecasts = (int *)malloc(num_valid_forecasts * sizeof(int));

                if (!valid_forecasts)
                {
                    fprintf(stderr, "Erro: Falha na alocação de valid_forecasts\n");
                    continue;
                }

                // Segundo passo: coletar forecasts válidos
                int valid_idx = 0;
                for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
                {
                    if (is_window_valid(&predictor_file->var[n], forecast, ds->k,
                                        ds->win_size, predictor_file->dim->len))
                    {
                        valid_forecasts[valid_idx] = forecast;
                        valid_idx++;
                    }
                }

                // Processamento em lotes para melhor utilização de cache
                if (valid_idx > 0)
                {
                    int batch_size = 100; // Ajustar baseado no cache do sistema
                    for (int batch_start = 0; batch_start < valid_idx; batch_start += batch_size)
                    {
                        int batch_end = batch_start + batch_size;
                        if (batch_end > valid_idx)
                            batch_end = valid_idx;

                        for (int i = batch_start; i < batch_end; i++)
                        {
                            int found = 0;
                            int forecast = valid_forecasts[i];

                            // Alocar pontos mais próximos com segurança
                            ClosestPoint *closest = allocate_closest_points_safe(ds->num_Na);
                            if (!closest)
                            {
                                fprintf(stderr, "Erro: Falha na alocação de ClosestPoint\n");
                                continue;
                            }

                            // Initialize current best distance for early termination
                            ds->current_best_distance = INFINITY;

                            // Search for nearest neighbors using the balanced tree
                            search_closest_points(root, &predictor_file->var[n], ds,
                                                  closest, forecast, 0, &found);

                            // Usar função corrigida de reconstrução
                            int created_data_index = forecast - ds->start_prediction;
                            recreate_data_fixed(predicted_file, ds, closest,
                                                created_data_index, n, found);

                            free(closest);
                            f_count++;
                        }
                    }
                }

                // Free allocated memory
                free(valid_forecasts);
            }

            gettimeofday(&end, 0);
            seconds = end.tv_sec - begin.tv_sec;
            microseconds = end.tv_usec - begin.tv_usec;
            elapsed = seconds + microseconds * 1e-6;
            printf("%.3f,", elapsed);

            // Validar processo e calcular RMSE
            if (validate_reconstruction_process(predicted_file, ds, n))
            {
                calculate_rmse_fixed(predicted_file, ds, n);
                // run_complete_diagnostic(predicted_file, ds, n, "PARTIAL_INDEPENDENT_FIXED_OPTIMIZED");
                printf("%.3lf,", predicted_file->var[n].rmse);
            }
            else
            {
                printf("Erro: Processo de reconstrução falhou para variável %d\n", n);
                predicted_file->var[n].rmse = NAN;
                printf("NaN,");
            }
        }
    }

    // Free the global node pool at the end
    free_node_pool(global_pool);
}

// ========== IMPLEMENTAÇÃO PARALELA ==========

// ========== WORKERS ==========

void *exhaustive_worker_thread(void *arg)
{
    WorkerData *worker = (WorkerData *)arg;
    ThreadData *shared = worker->shared;

#ifdef DEBUG_THREADS
    printf("[Thread %d] Processando forecasts %d a %d\n",
           worker->thread_id, worker->start_idx, worker->end_idx - 1);
#endif

    // Processar forecasts atribuídos a esta thread
    for (int i = worker->start_idx; i < worker->end_idx; i++)
    {
        int forecast = shared->valid_forecasts[i];
        int found = 0;

        ClosestPoint *closest = allocate_closest_points_safe(shared->ds->num_Na);
        if (!closest)
        {
            fprintf(stderr, "[Thread %d] Erro na alocação de ClosestPoint\n", worker->thread_id);
            continue;
        }

        // Buscar analogs válidos
        for (int analog = shared->ds->start_training; analog <= shared->ds->end_training; analog++)
        {
            // Validar janela do analog
            if (!is_window_valid(&shared->predictor_file->var[shared->n], analog, shared->ds->k,
                                 shared->ds->win_size, shared->predictor_file->dim->len))
            {
                continue;
            }

            // Calcular distância
            double distance = monache_metric_super_window(shared->predictor_file, shared->ds,
                                                          forecast, analog, shared->n);

            if (!isnan(distance))
            {
                if (found < shared->ds->num_Na)
                {
                    closest[found].window_index = analog;
                    closest[found].distance = distance;
                    found++;
                    if (found == shared->ds->num_Na)
                    {
                        qsort(closest, shared->ds->num_Na, sizeof(ClosestPoint),
                              compare_closest_point_ord_const);
                    }
                }
                else if (distance < closest[0].distance)
                {
                    closest[0].window_index = analog;
                    closest[0].distance = distance;
                    qsort(closest, shared->ds->num_Na, sizeof(ClosestPoint),
                          compare_closest_point_ord_const);
                }
            }
        }

        // ESCRITA DIRETA -!
        // Cada thread escreve em posições diferentes, logo é thread-safe
        int created_data_index = forecast - shared->ds->start_prediction;
        recreate_data_fixed(shared->predicted_file, shared->ds, closest,
                            created_data_index, shared->n, found);

        free(closest);
    }

#ifdef DEBUG_THREADS
    printf("[Thread %d] Finalizou processamento\n", worker->thread_id);
#endif

    return NULL;
}

void *partial_worker_thread(void *arg)
{
    WorkerData *worker = (WorkerData *)arg;
    ThreadData *shared = worker->shared;

#ifdef DEBUG_THREADS
    printf("[Thread %d] Processando forecasts %d a %d\n",
           worker->thread_id, worker->start_idx, worker->end_idx - 1);
#endif

    // Criar DataSegment local para evitar race condition em current_best_distance
    DataSegment local_ds = *shared->ds;

    // Processar forecasts atribuídos a esta thread
    for (int i = worker->start_idx; i < worker->end_idx; i++)
    {
        int forecast = shared->valid_forecasts[i];
        int found = 0;

        ClosestPoint *closest = allocate_closest_points_safe(shared->ds->num_Na);
        if (!closest)
        {
            fprintf(stderr, "[Thread %d] Erro na alocação de ClosestPoint\n", worker->thread_id);
            continue;
        }

        // Usar DataSegment local para thread safety
        local_ds.current_best_distance = INFINITY;

        // Usar árvore KD compartilhada (thread-safe para leitura)
        search_closest_points(shared->root, &shared->predictor_file->var[shared->n],
                              &local_ds, closest, forecast, 0, &found);

        // Cada thread escreve em posições diferentes, logo é thread-safe
        int created_data_index = forecast - shared->ds->start_prediction;
        recreate_data_fixed(shared->predicted_file, shared->ds, closest,
                            created_data_index, shared->n, found);

        free(closest);
    }

#ifdef DEBUG_THREADS
    printf("[Thread %d] Finalizou processamento\n", worker->thread_id);
#endif

    return NULL;
}

// ========== MAIN FUNCTIONS ==========

void exhaustive_processing_dependent_fixed_parallel(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    NetCDF *predictor_file = &file[1];

    // printf("Executando EXHAUSTIVE PARALELO com %d threads\n", ds->num_thread);

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            unsigned int length = (ds->end_prediction - ds->start_prediction) + 1;

            // Alocar memória para dados reconstruídos
            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            if (!predicted_file->var[n].created_data)
                continue;

            // Inicializar com NaN
            for (int i = 0; i < length; i++)
            {
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                case NC_DOUBLE:
                    ((double *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                }
            }

            // Coletar forecasts válidos
            int total_forecasts = ds->end_prediction - ds->start_prediction + 1;
            int *valid_forecasts = (int *)malloc(total_forecasts * sizeof(int));
            int num_valid_forecasts = 0;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                if (is_window_valid(&predictor_file->var[n], forecast, ds->k,
                                    ds->win_size, predictor_file->dim->len))
                {
                    valid_forecasts[num_valid_forecasts++] = forecast;
                }
            }

            // printf("Variável %d: %d forecasts válidos para processar\n", n, num_valid_forecasts);

            if (num_valid_forecasts == 0)
            {
                free(valid_forecasts);
                continue;
            }

            // Configuração paralela
            pthread_t threads[ds->num_thread];
            WorkerData workers[ds->num_thread];
            ThreadData shared_data;

            // Configurar dados compartilhados
            shared_data.predicted_file = predicted_file;
            shared_data.predictor_file = predictor_file;
            shared_data.ds = ds;
            shared_data.n = n;
            shared_data.valid_forecasts = valid_forecasts;
            shared_data.num_valid_forecasts = num_valid_forecasts;

            // Distribuir trabalho entre threads
            int forecasts_per_thread = num_valid_forecasts / ds->num_thread;
            int remaining_forecasts = num_valid_forecasts % ds->num_thread;

            struct timeval begin, end;
            gettimeofday(&begin, 0);

            // Criar e iniciar threads
            for (int t = 0; t < ds->num_thread; t++)
            {
                workers[t].shared = &shared_data;
                workers[t].thread_id = t;
                workers[t].start_idx = t * forecasts_per_thread;
                workers[t].end_idx = (t + 1) * forecasts_per_thread;

                // Última thread pega os forecasts restantes
                if (t == ds->num_thread - 1)
                {
                    workers[t].end_idx += remaining_forecasts;
                }

                if (pthread_create(&threads[t], NULL, exhaustive_worker_thread, &workers[t]) != 0)
                {
                    fprintf(stderr, "Erro ao criar thread %d\n", t);
                    exit(1);
                }
            }

            // Aguardar todas as threads terminarem
            for (int t = 0; t < ds->num_thread; t++)
            {
                pthread_join(threads[t], NULL);
            }

            gettimeofday(&end, 0);
            double elapsed = (end.tv_sec - begin.tv_sec) + (end.tv_usec - begin.tv_usec) * 1e-6;

            // printf("Tempo paralelo: %.3f segundos\n", elapsed);
            printf("%.3f,", elapsed);

            // Limpeza
            free(valid_forecasts);
        }

        // Calcular RMSE
        if (validate_reconstruction_process(predicted_file, ds, n))
        {
            calculate_rmse_fixed(predicted_file, ds, n);
            // run_complete_diagnostic(predicted_file, ds, n, "EXHAUSTIVE_PARALLEL");
            printf("%.3lf,", predicted_file->var[n].rmse);
        }
        else
        {
            predicted_file->var[n].rmse = NAN;
            printf("NaN,");
        }
    }
}

void partial_processing_independent_fixed_parallel(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    NetCDF *predictor_file = &file[1];

    // printf("Executando PARTIAL PARALELO com %d threads\n", ds->num_thread);

    NodePool *global_pool = create_node_pool();

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            unsigned int length = (ds->end_prediction - ds->start_prediction) + 1;
            reset_node_pool(global_pool);

            // Alocar memória para dados reconstruídos
            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                printf("Warning: Tipo não suportado na versão paralela sem mutex.\n");
                break;
            }

            if (!predicted_file->var[n].created_data)
                continue;

            // Inicializar com NaN
            for (int i = 0; i < length; i++)
            {
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                case NC_DOUBLE:
                    ((double *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                }
            }

            // Construir árvore KD (sequencial)
            int total_training_points = ds->end_training - ds->start_training + 1;
            int *training_indices = (int *)malloc(total_training_points * sizeof(int));
            int valid_training_points = 0;

            for (int analog = ds->start_training; analog <= ds->end_training; analog++)
            {
                if (is_window_valid(&predictor_file->var[n], analog, ds->k,
                                    ds->win_size, predictor_file->dim->len))
                {
                    training_indices[valid_training_points] = analog;
                    valid_training_points++;
                }
            }

            KDTree *root = NULL;
            if (valid_training_points > 0)
            {
                root = build_balanced_kdtree(training_indices, valid_training_points,
                                             &predictor_file->var[n], ds, 0, global_pool);
            }

            free(training_indices);

            // Coletar forecasts válidos
            int total_forecasts = ds->end_prediction - ds->start_prediction + 1;
            int *valid_forecasts = (int *)malloc(total_forecasts * sizeof(int));
            int num_valid_forecasts = 0;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                if (is_window_valid(&predictor_file->var[n], forecast, ds->k,
                                    ds->win_size, predictor_file->dim->len))
                {
                    valid_forecasts[num_valid_forecasts++] = forecast;
                }
            }

            // printf("Variável %d: %d analogs válidos, %d forecasts válidos\n",
            //        n, valid_training_points, num_valid_forecasts);

            if (num_valid_forecasts == 0 || !root)
            {
                free(valid_forecasts);
                continue;
            }

            // Processamento paralelo
            pthread_t threads[ds->num_thread];
            WorkerData workers[ds->num_thread];
            ThreadData shared_data;

            // Configurar dados compartilhados
            shared_data.predicted_file = predicted_file;
            shared_data.predictor_file = predictor_file;
            shared_data.ds = ds;
            shared_data.n = n;
            shared_data.root = root;
            shared_data.valid_forecasts = valid_forecasts;
            shared_data.num_valid_forecasts = num_valid_forecasts;

            // Distribuir trabalho entre threads
            int forecasts_per_thread = num_valid_forecasts / ds->num_thread;
            int remaining_forecasts = num_valid_forecasts % ds->num_thread;

            struct timeval begin, end;
            gettimeofday(&begin, 0);

            // Criar e iniciar threads
            for (int t = 0; t < ds->num_thread; t++)
            {
                workers[t].shared = &shared_data;
                workers[t].thread_id = t;
                workers[t].start_idx = t * forecasts_per_thread;
                workers[t].end_idx = (t + 1) * forecasts_per_thread;

                // Última thread pega os forecasts restantes
                if (t == ds->num_thread - 1)
                {
                    workers[t].end_idx += remaining_forecasts;
                }

                if (pthread_create(&threads[t], NULL, partial_worker_thread, &workers[t]) != 0)
                {
                    fprintf(stderr, "Erro ao criar thread %d\n", t);
                    exit(1);
                }
            }

            // Aguardar todas as threads terminarem
            for (int t = 0; t < ds->num_thread; t++)
            {
                pthread_join(threads[t], NULL);
            }

            gettimeofday(&end, 0);
            double elapsed = (end.tv_sec - begin.tv_sec) + (end.tv_usec - begin.tv_usec) * 1e-6;

            // printf("Tempo paralelo: %.3f segundos\n", elapsed);
            printf("%.3f,", elapsed);

            // Limpeza
            free(valid_forecasts);
        }

        // Calcular RMSE
        if (validate_reconstruction_process(predicted_file, ds, n))
        {
            calculate_rmse_fixed(predicted_file, ds, n);
            // run_complete_diagnostic(predicted_file, ds, n, "PARTIAL_PARALLEL_NO_MUTEX");
            printf("%.3lf,", predicted_file->var[n].rmse);
        }
        else
        {
            predicted_file->var[n].rmse = NAN;
            printf("NaN,");
        }
    }

    free_node_pool(global_pool);
}
