#!/bin/bash

DATEPLUS=$(date +"%Y%m%d%H%M%S.%N")
BASE_DIR=/home/P050.17Jun25

function slaptime(){
    FILENAME=$BASE_DIR/test/$1.$DATEPLUS".csv"
    mkdir -p $(dirname $FILENAME)
    echo "" > $FILENAME

    echo n_loop,n_files,n_threads,t_rdfiles,s_training,e_training,s_prediction,e_prediction,rmse,t_total >> $FILENAME

    export LD_LIBRARY_PATH=/usr/local/lib/

    for t in 8; do # training period in years
        for i in 1; do # threads number
            for j in $(seq 1 $2); do # how many times
                echo "countdown - test" $i - $j
                sleep 15
                echo $j,$($BASE_DIR/bin/generic_app $i $t $(ls $BASE_DIR/support/nc_data/-*.nc)) >> $FILENAME
            done
        done
    done
}

$1 $2 $3 $4
# echo 0:$0 1:$1 2:$2 3:$3 4:$4 5:$5