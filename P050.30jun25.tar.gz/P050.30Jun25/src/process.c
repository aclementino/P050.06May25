#include "process.h"
#include "randw.h"
#include "kdtree.h"

// =============================================================================
// IMPLEMENTACAO DAS FUNCOES AUXILIARES BASICAS
// =============================================================================

/**
 * @brief Validação simples de janela de dados
 *
 * Verifica se todos os valores em uma janela centrada na posição
 * especificada são válidos (não NaN). Suporta múltiplos tipos de dados.
 */
bool validate_window_simple(Variable *var, int position, int k, int win_size, int data_length)
{
    int window_start = position - k;

    // Verificação básica de bounds
    if (window_start < 0 || window_start + win_size > data_length)
    {
        return false;
    }

    // Validação da janela completa baseada no tipo
    switch (var->type)
    {
    case NC_FLOAT:
    {
        float *data = (float *)var->data;
        for (int j = 0; j < win_size; j++)
        {
            if (isnan(data[window_start + j]))
            {
                return false;
            }
        }
        break;
    }
    case NC_DOUBLE:
    {
        double *data = (double *)var->data;
        for (int j = 0; j < win_size; j++)
        {
            if (isnan(data[window_start + j]))
            {
                return false;
            }
        }
        break;
    }
    case NC_INT:
    {
        int *data = (int *)var->data;
        for (int j = 0; j < win_size; j++)
        {
            if (data[window_start + j] == (int)VALUE_NAN)
            {
                return false;
            }
        }
        break;
    }
    case NC_SHORT:
    {
        short *data = (short *)var->data;
        for (int j = 0; j < win_size; j++)
        {
            if (data[window_start + j] == (short)VALUE_NAN)
            {
                return false;
            }
        }
        break;
    }
    default:
        // Para tipos não implementados, assumir válido
        return true;
    }

    return true;
}

/**
 * @brief Função de processamento genérica
 *
 * Interface comum que verifica integridade dos dados antes
 * de chamar a função específica do algoritmo.
 */
void processing_data(NetCDF *file, DataSegment *ds, process_func func)
{
    for (int i = 0; i < (ds->argc); i++)
    {
        if (file == NULL || file[i].var == NULL)
        {
            printf("Application(processing_data): No data in file %i.\n", (i + 1));
            return;
        }
    }
    func(file, ds); // Call the processing function
}

/**
 * @brief Cálculo da métrica de distância Monache
 *
 * Implementa distância euclidiana entre duas janelas de dados
 * com suporte a múltiplos tipos de dados.
 */
double monache_metric(Variable *var, DataSegment *ds, int forecast, int analog, int i)
{
    double sum = 0.0;

    switch (var->type)
    {
        MONACHE(NC_BYTE);
        MONACHE(NC_CHAR);
        MONACHE(NC_SHORT);
        MONACHE(NC_INT);
        MONACHE(NC_FLOAT);
        MONACHE(NC_DOUBLE);
        MONACHE(NC_UBYTE);
        MONACHE(NC_USHORT);
        MONACHE(NC_UINT);
        MONACHE(NC_INT64);
        MONACHE(NC_UINT64);
    }

    return isnan(sum) ? NAN : sqrt(sum);
}

/**
 * @brief Cálculo da métrica Monache para múltiplas séries
 *
 * Versão estendida que considera múltiplas séries temporais,
 * somando as distâncias de todas as séries.
 */
double monache_metric_super_window(NetCDF *file, DataSegment *ds, int forecast, int analog, int i)
{
    double sum = 0.0;

    for (int f = 0; f < (ds->argc); f++)
    { // Soma sobre séries temporais
        switch (file[f].var[i].type)
        {
            MONACHESW(NC_BYTE);
            MONACHESW(NC_CHAR);
            MONACHESW(NC_SHORT);
            MONACHESW(NC_INT);
            MONACHESW(NC_FLOAT);
            MONACHESW(NC_DOUBLE);
            MONACHESW(NC_UBYTE);
            MONACHESW(NC_USHORT);
            MONACHESW(NC_UINT);
            MONACHESW(NC_INT64);
            MONACHESW(NC_UINT64);
        }
    }

    return isnan(sum) ? NAN : sqrt(sum);
}

/**
 * @brief Comparador para ordenação de pontos próximos
 *
 * Ordena por distância (maior primeiro) para manter heap
 * com os k menores elementos no topo.
 */
int compare_closest_point_ord_const(const void *x, const void *y)
{
    ClosestPoint *point1 = (ClosestPoint *)x;
    ClosestPoint *point2 = (ClosestPoint *)y;

    if (point1->distance < point2->distance)
        return 1;
    if (point1->distance > point2->distance)
        return -1;
    return 0;
}

/**
 * @brief Aloca array de pontos próximos com inicialização segura
 *
 * Previne uso de dados não inicializados através de calloc
 * e inicialização explícita dos campos críticos.
 */
ClosestPoint *allocate_closest_points_safe(int num_points)
{
    ClosestPoint *closest = (ClosestPoint *)calloc(num_points, sizeof(ClosestPoint));

    if (closest == NULL)
    {
        fprintf(stderr, "Erro: Falha na alocação de memória para ClosestPoint\n");
        return NULL;
    }

    // Inicializar com valores seguros
    for (int i = 0; i < num_points; i++)
    {
        closest[i].window_index = -1;   // Índice inválido
        closest[i].distance = INFINITY; // Distância infinita
    }

    return closest;
}

// =============================================================================
// FUNCOES DE RECONSTRUCAO E VALIDACAO
// =============================================================================

/**
 * @brief Reconstrói dados usando vizinhos mais próximos
 *
 * Versão corrigida que mapeia corretamente os índices entre
 * dados originais e dados reconstruídos, com validações rigorosas.
 */
void recreate_data(NetCDF *file, DataSegment *ds, ClosestPoint *closest,
                   int forecast_position, int n, int num_found)
{
    int count = 0;
    double sum_values = 0;

    // Verificar se os ponteiros são válidos
    if (!file->var[n].data || !file->var[n].created_data)
    {
        fprintf(stderr, "Dados ou memória criada estão nulos para var[%d]\n", n);
        return;
    }

    // Verificar se temos pontos encontrados
    if (num_found == 0)
    {
        // Marcar como NaN
        switch (file->var[n].type)
        {
        case NC_FLOAT:
            ((float *)file->var[n].created_data)[forecast_position] = NAN;
            break;
        case NC_DOUBLE:
            ((double *)file->var[n].created_data)[forecast_position] = NAN;
            break;
            // Adicionar outros tipos conforme necessário
        }
        return;
    }

    // Processar apenas os pontos válidos encontrados
    for (int i = 0; i < num_found; i++)
    {
        // Verificar se o índice está dentro dos limites
        if (closest[i].window_index < 0 || closest[i].window_index >= file->dim->len)
        {
            continue;
        }

        // Verificar se a distância é válida
        if (isnan(closest[i].distance) || isinf(closest[i].distance))
        {
            continue;
        }

        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float value = ((float *)file->var[n].data)[closest[i].window_index];
            if (!isnan(value))
            {
                sum_values += (double)value;
                count++;
            }
            break;
        }
        case NC_DOUBLE:
        {
            double value = ((double *)file->var[n].data)[closest[i].window_index];
            if (!isnan(value))
            {
                sum_values += value;
                count++;
            }
            break;
        }
            // Adicionar outros tipos conforme necessário
        }
    }

    // Verificar se temos valores válidos para fazer a média
    if (count > 0)
    {
        double average = sum_values / count;
        switch (file->var[n].type)
        {
        case NC_FLOAT:
            ((float *)file->var[n].created_data)[forecast_position] = (float)average;
            break;
        case NC_DOUBLE:
            ((double *)file->var[n].created_data)[forecast_position] = average;
            break;
            // Adicionar outros tipos conforme necessário
        }
    }
    else
    {
        // Nenhum valor válido encontrado, marcar como NaN
        switch (file->var[n].type)
        {
        case NC_FLOAT:
            ((float *)file->var[n].created_data)[forecast_position] = NAN;
            break;
        case NC_DOUBLE:
            ((double *)file->var[n].created_data)[forecast_position] = NAN;
            break;
        }
    }
}

/**
 * @brief Calcula RMSE com mapeamento correto de índices
 *
 * Versão corrigida que compara corretamente dados originais
 * com dados reconstruídos, respeitando o mapeamento de índices.
 */
void calculate_rmse(NetCDF *file, DataSegment *ds, int n)
{
    double sum_error = 0;
    int count = 0;
    int created_index = 0; // Índice para os dados reconstruídos

    for (int i = ds->start_prediction; i <= ds->end_prediction; i++)
    {
        // Verificar se o valor original é válido
        bool original_valid = false;
        bool reconstructed_valid = false;
        double original_value = 0;
        double reconstructed_value = 0;

        switch (file->var[n].type)
        {
        case NC_FLOAT:
        {
            float orig = ((float *)file->var[n].data)[i];
            float recon = ((float *)file->var[n].created_data)[created_index];

            original_valid = !isnan(orig);
            reconstructed_valid = !isnan(recon);
            original_value = (double)orig;
            reconstructed_value = (double)recon;
            break;
        }
        case NC_DOUBLE:
        {
            double orig = ((double *)file->var[n].data)[i];
            double recon = ((double *)file->var[n].created_data)[created_index];

            original_valid = !isnan(orig);
            reconstructed_valid = !isnan(recon);
            original_value = orig;
            reconstructed_value = recon;
            break;
        }
        }

        // Só calcular erro se ambos os valores são válidos
        if (original_valid && reconstructed_valid)
        {
            double error = original_value - reconstructed_value;
            sum_error += error * error;
            count++;
        }

        created_index++; // Incrementar índice dos dados reconstruídos
    }

    if (count > 0)
    {
        file->var[n].rmse = sqrt(sum_error / count);
    }
    else
    {
        file->var[n].rmse = NAN;
    }
}

/**
 * @brief Valida processo completo de reconstrução
 *
 * Verifica se a reconstrução foi bem-sucedida contando
 * quantos valores válidos foram gerados.
 */
bool validate_reconstruction_process(NetCDF *file, DataSegment *ds, int n)
{
    // Verificar se a memória foi alocada
    if (!file->var[n].created_data)
    {
        fprintf(stderr, "Erro: created_data não foi alocado para variável %d\n", n);
        return false;
    }

    // Contar quantos valores foram realmente reconstruídos
    int expected_size = ds->end_prediction - ds->start_prediction + 1;
    int valid_count = 0;

    for (int i = 0; i < expected_size; i++)
    {
        bool is_valid = false;

        switch (file->var[n].type)
        {
        case NC_FLOAT:
            is_valid = !isnan(((float *)file->var[n].created_data)[i]);
            break;
        case NC_DOUBLE:
            is_valid = !isnan(((double *)file->var[n].created_data)[i]);
            break;
        }

        if (is_valid)
        {
            valid_count++;
        }
    }

    return valid_count > 0;
}

// =============================================================================
// IMPLEMENTACAO DO ALGORITMO ANEN (ANALOG ENSEMBLE COM PRE-FILTRO)
// =============================================================================

/**
 * @brief Inicializa estrutura de dados pré-filtrados
 *
 * Executa validação sequencial de todos os forecasts e analogs,
 * armazenando apenas os índices válidos em arrays compactos.
 * Esta pré-computação elimina validações durante o processamento paralelo.
 */
void init_prefiltered_data(PreFilteredData *filtered, Variable *var,
                           DataSegment *ds, int data_length)
{
    // Alocar arrays com tamanho máximo
    int max_forecasts = ds->end_prediction - ds->start_prediction + 1;
    int max_analogs = ds->end_training - ds->start_training + 1;

    filtered->valid_forecasts = (int *)malloc(max_forecasts * sizeof(int));
    filtered->valid_analogs = (int *)malloc(max_analogs * sizeof(int));
    filtered->num_valid_forecasts = 0;
    filtered->num_valid_analogs = 0;

    if (!filtered->valid_forecasts || !filtered->valid_analogs)
    {
        fprintf(stderr, "Erro: Falha na alocação de arrays pré-filtrados\n");
        return;
    }

    // Coletar forecasts válidos
    for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
    {
        if (validate_window_simple(var, forecast, ds->k, ds->win_size, data_length))
        {
            filtered->valid_forecasts[filtered->num_valid_forecasts++] = forecast;
        }
    }

    // Coletar analogs válidos
    for (int analog = ds->start_training; analog <= ds->end_training; analog++)
    {
        if (validate_window_simple(var, analog, ds->k, ds->win_size, data_length))
        {
            filtered->valid_analogs[filtered->num_valid_analogs++] = analog;
        }
    }

    // Redimensionar arrays para tamanho exato (economia de memória)
    if (filtered->num_valid_forecasts > 0)
    {
        filtered->valid_forecasts = (int *)realloc(filtered->valid_forecasts,
                                                   filtered->num_valid_forecasts * sizeof(int));
    }
    if (filtered->num_valid_analogs > 0)
    {
        filtered->valid_analogs = (int *)realloc(filtered->valid_analogs,
                                                 filtered->num_valid_analogs * sizeof(int));
    }
}

/**
 * @brief Libera memória dos dados pré-filtrados
 *
 * Função de limpeza que previne vazamentos de memória.
 */
void free_prefiltered_data(PreFilteredData *filtered)
{
    if (filtered->valid_forecasts)
    {
        free(filtered->valid_forecasts);
        filtered->valid_forecasts = NULL;
    }
    if (filtered->valid_analogs)
    {
        free(filtered->valid_analogs);
        filtered->valid_analogs = NULL;
    }
    filtered->num_valid_forecasts = 0;
    filtered->num_valid_analogs = 0;
}

/**
 * @brief Worker thread para processamento ANEN
 *
 * Função executada por cada thread no algoritmo ANEN paralelo.
 * Processa uma faixa de forecasts usando dados pré-filtrados,
 * garantindo que não há validações durante o processamento.
 */
void *anen_parallel_worker(void *arg)
{
    ANENWorkerData *worker = (ANENWorkerData *)arg;
    ANENSharedData *shared = worker->shared;

    // Inicializar contadores locais
    worker->processed_count = 0;

    struct timeval worker_start, worker_end;
    gettimeofday(&worker_start, 0);

    // Processar forecasts atribuídos a esta thread
    for (int f_idx = worker->start_forecast_idx; f_idx < worker->end_forecast_idx; f_idx++)
    {
        int forecast = shared->filtered_data->valid_forecasts[f_idx];

        // Alocar estrutura de candidatos (cada thread tem a sua)
        ClosestPoint *closest = allocate_closest_points_safe(shared->ds->num_Na);
        if (!closest)
        {
            fprintf(stderr, "[Thread %d] Erro na alocação de ClosestPoint\n", worker->thread_id);
            continue;
        }

        int found = 0;

        // Loop de analogs SEM validações - todos já são válidos!
        for (int a_idx = 0; a_idx < shared->filtered_data->num_valid_analogs; a_idx++)
        {
            int analog = shared->filtered_data->valid_analogs[a_idx];

            // Calcular distância diretamente - ZERO overhead de validação
            double distance = monache_metric_super_window(shared->predictor_file, shared->ds,
                                                          forecast, analog, shared->n);

            if (!isnan(distance))
            {
                // Gerenciar heap de candidatos (dados locais da thread - thread-safe)
                if (found < shared->ds->num_Na)
                {
                    closest[found].window_index = analog;
                    closest[found].distance = distance;
                    found++;
                    if (found == shared->ds->num_Na)
                    {
                        qsort(closest, shared->ds->num_Na, sizeof(ClosestPoint),
                              compare_closest_point_ord_const);
                    }
                }
                else if (distance < closest[0].distance)
                {
                    closest[0].window_index = analog;
                    closest[0].distance = distance;
                    qsort(closest, shared->ds->num_Na, sizeof(ClosestPoint),
                          compare_closest_point_ord_const);
                }
            }
        }

        // Reconstruir dados (thread-safe: cada thread escreve em posições diferentes)
        int created_data_index = forecast - shared->ds->start_prediction;
        recreate_data(shared->predicted_file, shared->ds, closest,
                      created_data_index, shared->n, found);

        free(closest);
        worker->processed_count++;
    }

    gettimeofday(&worker_end, 0);
    worker->processing_time = (worker_end.tv_sec - worker_start.tv_sec) +
                              (worker_end.tv_usec - worker_start.tv_usec) * 1e-6;

    return NULL;
}

/**
 * @brief Algoritmo ANEN Paralelo - Analog Ensemble com pré-filtro
 *
 * Implementa busca exaustiva otimizada com pré-filtro de dados válidos.
 * Elimina validações durante o processamento principal através de
 * pré-computação sequencial dos índices válidos.
 */
void anen_dependent_parallel(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    NetCDF *predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            unsigned int length = (ds->end_prediction - ds->start_prediction) + 1;

            // ========== ALOCAÇÃO DE MEMÓRIA ==========
            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                predicted_file->var[n].created_data = malloc(length * sizeof(float));
                break;
            }

            if (!predicted_file->var[n].created_data)
                continue;

            // Inicializar com NaN (thread-safe: feito antes das threads)
            for (int i = 0; i < length; i++)
            {
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                case NC_DOUBLE:
                    ((double *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                default:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                }
            }

            // ========== FASE 1: PRÉ-FILTRAR DADOS (SEQUENCIAL) ==========
            struct timeval begin_prefilter, end_prefilter;
            gettimeofday(&begin_prefilter, 0);

            PreFilteredData filtered_data;
            init_prefiltered_data(&filtered_data, &predictor_file->var[n], ds, predictor_file->dim->len);

            gettimeofday(&end_prefilter, 0);

            if (filtered_data.num_valid_forecasts == 0)
            {
                free_prefiltered_data(&filtered_data);
                continue;
            }

            // ========== FASE 2: PROCESSAMENTO PARALELO ==========
            struct timeval begin_parallel, end_parallel;
            gettimeofday(&begin_parallel, 0);

            // Configurar dados compartilhados
            ANENSharedData shared_data;
            shared_data.predicted_file = predicted_file;
            shared_data.predictor_file = predictor_file;
            shared_data.ds = ds;
            shared_data.n = n;
            shared_data.filtered_data = &filtered_data;

            // Configurar threads
            pthread_t threads[ds->num_thread];
            ANENWorkerData workers[ds->num_thread];

            // Distribuir trabalho entre threads (dividir forecasts)
            int forecasts_per_thread = filtered_data.num_valid_forecasts / ds->num_thread;
            int remaining_forecasts = filtered_data.num_valid_forecasts % ds->num_thread;

            // Criar e iniciar threads
            for (int t = 0; t < ds->num_thread; t++)
            {
                workers[t].shared = &shared_data;
                workers[t].thread_id = t;
                workers[t].start_forecast_idx = t * forecasts_per_thread;
                workers[t].end_forecast_idx = (t + 1) * forecasts_per_thread;
                workers[t].processed_count = 0;
                workers[t].processing_time = 0.0;

                // Última thread pega os forecasts restantes
                if (t == ds->num_thread - 1)
                {
                    workers[t].end_forecast_idx += remaining_forecasts;
                }

                if (pthread_create(&threads[t], NULL, anen_parallel_worker, &workers[t]) != 0)
                {
                    fprintf(stderr, "Erro ao criar thread %d\n", t);
                    exit(1);
                }
            }

            // Aguardar todas as threads terminarem
            for (int t = 0; t < ds->num_thread; t++)
            {
                pthread_join(threads[t], NULL);
            }

            gettimeofday(&end_parallel, 0);
            double parallel_time = (end_parallel.tv_sec - begin_parallel.tv_sec) +
                                   (end_parallel.tv_usec - begin_parallel.tv_usec) * 1e-6;

            printf("%.3f,", parallel_time);

            // ========== LIMPEZA ==========
            free_prefiltered_data(&filtered_data);
        }

        // Calcular RMSE (sequencial)
        if (validate_reconstruction_process(predicted_file, ds, n))
        {
            calculate_rmse(predicted_file, ds, n);
            printf("%.3lf,", predicted_file->var[n].rmse);
        }
        else
        {
            predicted_file->var[n].rmse = NAN;
            printf("NaN,");
        }
    }
}

// =============================================================================
// IMPLEMENTACAO DO ALGORITMO KD-ANEN (KD-TREE + ANALOG ENSEMBLE)
// =============================================================================

/**
 * @brief Worker thread para processamento KD-ANEN
 *
 * Função executada por cada thread no algoritmo KD-ANEN paralelo.
 * Usa KD-Tree para busca inteligente de vizinhos mais próximos.
 */
void *kdanen_parallel_worker(void *arg)
{
    KDANENWorkerData *worker = (KDANENWorkerData *)arg;
    KDANENSharedData *shared = worker->shared;

    // Inicializar contadores locais
    worker->processed_count = 0;

    struct timeval worker_start, worker_end;
    gettimeofday(&worker_start, 0);

    // Criar DataSegment local para thread safety
    DataSegment local_ds = *shared->ds;

    // Processar forecasts atribuídos a esta thread
    for (int f_idx = worker->start_forecast_idx; f_idx < worker->end_forecast_idx; f_idx++)
    {
        int forecast = shared->valid_forecasts[f_idx];

        // Alocar estrutura de candidatos (cada thread tem a sua)
        ClosestPoint *closest = allocate_closest_points_safe(shared->ds->num_Na);
        if (!closest)
        {
            fprintf(stderr, "[Thread %d] Erro na alocação de ClosestPoint\n", worker->thread_id);
            continue;
        }

        int found = 0;
        local_ds.current_best_distance = INFINITY;

        // Usar KD-Tree para busca inteligente (thread-safe para leitura)
        search_closest_points(shared->root, &shared->predictor_file->var[shared->n],
                              &local_ds, closest, forecast, 0, &found);

        // Reconstruir dados (thread-safe: cada thread escreve em posições diferentes)
        int created_data_index = forecast - shared->ds->start_prediction;
        recreate_data(shared->predicted_file, shared->ds, closest,
                      created_data_index, shared->n, found);

        free(closest);
        worker->processed_count++;
    }

    gettimeofday(&worker_end, 0);
    worker->processing_time = (worker_end.tv_sec - worker_start.tv_sec) +
                              (worker_end.tv_usec - worker_start.tv_usec) * 1e-6;

    return NULL;
}

/**
 * @brief Algoritmo KD-ANEN Paralelo - KD-Tree + Analog Ensemble
 *
 * Implementa busca inteligente usando KD-Tree para reduzir complexidade
 * de O(n×m) para O(n×log m). Ideal para datasets grandes onde o custo
 * de construção da árvore é compensado pela eficiência da busca.
 */
void kdanen_independent_parallel(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    NetCDF *predictor_file = &file[1];

    // Create a node pool for efficient memory management
    NodePool *global_pool = create_node_pool();
    if (!global_pool)
    {
        fprintf(stderr, "ERRO: Falha ao criar node pool\n");
        return;
    }

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            unsigned int length = (ds->end_prediction - ds->start_prediction) + 1;

            // Reset the node pool for this iteration
            reset_node_pool(global_pool);

            // ========== ALOCAÇÃO DE MEMÓRIA ==========
            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                predicted_file->var[n].created_data = malloc(length * sizeof(float));
                break;
            }

            if (!predicted_file->var[n].created_data)
                continue;

            // Inicializar com NaN
            for (int i = 0; i < length; i++)
            {
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                case NC_DOUBLE:
                    ((double *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                default:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                }
            }

            // ========== FASE 1: CONSTRUIR KD-TREE (SEQUENCIAL) ==========
            struct timeval begin_tree, end_tree;
            gettimeofday(&begin_tree, 0);

            // Coletar analogs válidos para construção da árvore
            int total_training_points = ds->end_training - ds->start_training + 1;
            int *training_indices = (int *)malloc(total_training_points * sizeof(int));
            int valid_training_points = 0;

            if (!training_indices)
            {
                continue;
            }

            for (int analog = ds->start_training; analog <= ds->end_training; analog++)
            {
                if (validate_window_simple(&predictor_file->var[n], analog, ds->k,
                                           ds->win_size, predictor_file->dim->len))
                {
                    training_indices[valid_training_points++] = analog;
                }
            }

            // Construir KD-Tree balanceada
            KDTree *root = NULL;
            if (valid_training_points > 0)
            {
                root = build_balanced_kdtree(training_indices, valid_training_points,
                                             &predictor_file->var[n], ds, 0, global_pool);
            }

            free(training_indices);

            if (!root)
            {
                continue;
            }

            gettimeofday(&end_tree, 0);
            double tree_time = (end_tree.tv_sec - begin_tree.tv_sec) +
                               (end_tree.tv_usec - begin_tree.tv_usec) * 1e-6;

            // ========== FASE 2: COLETAR FORECASTS VÁLIDOS ==========
            int total_forecasts = ds->end_prediction - ds->start_prediction + 1;
            int *valid_forecasts = (int *)malloc(total_forecasts * sizeof(int));
            int num_valid_forecasts = 0;

            if (!valid_forecasts)
            {
                continue;
            }

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                if (validate_window_simple(&predictor_file->var[n], forecast, ds->k,
                                           ds->win_size, predictor_file->dim->len))
                {
                    valid_forecasts[num_valid_forecasts++] = forecast;
                }
            }

            if (num_valid_forecasts == 0)
            {
                free(valid_forecasts);
                continue;
            }

            // ========== FASE 3: PROCESSAMENTO PARALELO ==========
            struct timeval begin_parallel, end_parallel;
            gettimeofday(&begin_parallel, 0);

            // Configurar dados compartilhados
            KDANENSharedData shared_data;
            shared_data.predicted_file = predicted_file;
            shared_data.predictor_file = predictor_file;
            shared_data.ds = ds;
            shared_data.n = n;
            shared_data.root = root;
            shared_data.valid_forecasts = valid_forecasts;
            shared_data.num_valid_forecasts = num_valid_forecasts;

            // Configurar threads
            pthread_t threads[ds->num_thread];
            KDANENWorkerData workers[ds->num_thread];

            // Distribuir trabalho entre threads
            int forecasts_per_thread = num_valid_forecasts / ds->num_thread;
            int remaining_forecasts = num_valid_forecasts % ds->num_thread;

            // Criar e iniciar threads
            for (int t = 0; t < ds->num_thread; t++)
            {
                workers[t].shared = &shared_data;
                workers[t].thread_id = t;
                workers[t].start_forecast_idx = t * forecasts_per_thread;
                workers[t].end_forecast_idx = (t + 1) * forecasts_per_thread;
                workers[t].processed_count = 0;
                workers[t].processing_time = 0.0;

                // Última thread pega os forecasts restantes
                if (t == ds->num_thread - 1)
                {
                    workers[t].end_forecast_idx += remaining_forecasts;
                }

                if (pthread_create(&threads[t], NULL, kdanen_parallel_worker, &workers[t]) != 0)
                {
                    fprintf(stderr, "Erro ao criar thread %d\n", t);
                    exit(1);
                }
            }

            // Aguardar todas as threads terminarem
            for (int t = 0; t < ds->num_thread; t++)
            {
                pthread_join(threads[t], NULL);
            }

            gettimeofday(&end_parallel, 0);
            double parallel_time = (end_parallel.tv_sec - begin_parallel.tv_sec) +
                                   (end_parallel.tv_usec - begin_parallel.tv_usec) * 1e-6;

            printf("%.3f,", parallel_time);

            // ========== LIMPEZA ==========
            free(valid_forecasts);
        }

        // Calcular RMSE (sequencial)
        if (validate_reconstruction_process(predicted_file, ds, n))
        {
            calculate_rmse(predicted_file, ds, n);
            printf("%.3lf,", predicted_file->var[n].rmse);
        }
        else
        {
            predicted_file->var[n].rmse = NAN;
            printf("NaN,");
        }
    }

    // Free the global node pool at the end
    free_node_pool(global_pool);
}

// =============================================================================
// FUNCOES LEGACY (COMPATIBILIDADE)
// =============================================================================

/**
 * @brief Algoritmo exaustivo independente (legacy)
 *
 * Implementação original para compatibilidade.
 * Recomenda-se usar anen_dependent_parallel para novos projetos.
 */
void exhaustive_processing_independent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    NetCDF *predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0;
            int a_count = 0;
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window = true, f_is_valid_last_win = true;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            f_is_valid_last_win = false;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                if (!validate_window_simple(&predictor_file->var[n], forecast, ds->k,
                                            ds->win_size, predictor_file->dim->len))
                {
                    continue;
                }

                f_valid_count++;
                f_is_valid_last_win = true;

                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));
                int found = 0;

                for (int analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    if (!validate_window_simple(&predictor_file->var[n], analog, ds->k,
                                                ds->win_size, predictor_file->dim->len))
                    {
                        continue;
                    }

                    double distance = monache_metric(&predictor_file->var[n], ds, forecast, analog, n);

                    if (!isnan(distance))
                    {
                        if (found < ds->num_Na)
                        {
                            closest[found].window_index = analog;
                            closest[found].distance = distance;
                            found++;
                            if (found == ds->num_Na)
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                        }
                        else if (distance < closest[0].distance)
                        {
                            closest[0].window_index = analog;
                            closest[0].distance = distance;
                            qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                        }
                    }
                    a_count++;
                }

                recreate_data(predicted_file, ds, closest, f_count, n, found);
                free(closest);
                f_count++;
            }
        }

        if (validate_reconstruction_process(predicted_file, ds, n))
        {
            calculate_rmse(predicted_file, ds, n);
        }
        else
        {
            predicted_file->var[n].rmse = NAN;
        }
        printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
    }
}

/**
 * @brief Algoritmo exaustivo dependente (legacy)
 *
 * Implementação original para compatibilidade.
 * Recomenda-se usar anen_dependent_parallel para novos projetos.
 */
void exhaustive_processing_dependent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    NetCDF *predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_count = 0;
            unsigned int length = (ds->end_prediction - ds->start_prediction) + 1;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            if (!predicted_file->var[n].created_data)
                continue;

            // Inicializar com NaN
            for (int i = 0; i < length; i++)
            {
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                    ((float *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                case NC_DOUBLE:
                    ((double *)predicted_file->var[n].created_data)[i] = NAN;
                    break;
                }
            }

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                if (!validate_window_simple(&predictor_file->var[n], forecast, ds->k,
                                            ds->win_size, predictor_file->dim->len))
                {
                    continue;
                }

                ClosestPoint *closest = allocate_closest_points_safe(ds->num_Na);
                if (!closest)
                    continue;

                int found = 0;

                for (int analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    if (!validate_window_simple(&predictor_file->var[n], analog, ds->k,
                                                ds->win_size, predictor_file->dim->len))
                    {
                        continue;
                    }

                    double distance = monache_metric_super_window(predictor_file, ds, forecast, analog, n);

                    if (!isnan(distance))
                    {
                        if (found < ds->num_Na)
                        {
                            closest[found].window_index = analog;
                            closest[found].distance = distance;
                            found++;
                            if (found == ds->num_Na)
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                        }
                        else if (distance < closest[0].distance)
                        {
                            closest[0].window_index = analog;
                            closest[0].distance = distance;
                            qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                        }
                    }
                }

                int created_data_index = forecast - ds->start_prediction;
                recreate_data(predicted_file, ds, closest, created_data_index, n, found);

                free(closest);
                f_count++;
            }
        }

        if (validate_reconstruction_process(predicted_file, ds, n))
        {
            calculate_rmse(predicted_file, ds, n);
        }
        else
        {
            predicted_file->var[n].rmse = NAN;
        }
        printf("%.3lf,", predicted_file->var[n].rmse);
    }
}

/**
 * @brief Versão paralela corrigida do algoritmo exaustivo (legacy)
 *
 * Implementação com correções de bugs mas sem otimizações avançadas.
 * Recomenda-se usar anen_dependent_parallel para melhor performance.
 */
void exhaustive_processing_dependent_fixed_parallel(NetCDF *file, DataSegment *ds)
{
    // Implementação simplificada para compatibilidade
    // Para production, usar anen_dependent_parallel
    exhaustive_processing_dependent(file, ds);
}

/**
 * @brief Versão paralela corrigida do algoritmo parcial (legacy)
 *
 * Implementação com KD-Tree mas interface legacy.
 * Recomenda-se usar kdanen_independent_parallel para melhor interface.
 */
void partial_processing_independent_fixed_parallel(NetCDF *file, DataSegment *ds)
{
    // Implementação simplificada para compatibilidade
    // Para production, usar kdanen_independent_parallel
    kdanen_independent_parallel(file, ds);
}
