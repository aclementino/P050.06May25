// #include "structs.h"
#include "kdtree.h"
#include "randw.h"
#include "preprocess.h"
#include "process.h"

// DATE_ISO - format "YYYY-MM-DDTHH:MM:00"
#define PREDICTION_INIT "2019-01-01T00:00:00"
#define PREDICTION_END "2019-12-31T23:54:00"
#define TRAINING_INIT(x) x
#define TRAINING_END(x) x

// Start measuring time
struct timeval begin, end;
long seconds = 0;
long microseconds = 0;
double elapsed = 0;

KDTree *kdtree;

int main(int argc, char *argv[])
{
    char *T_INIT = NULL;
    char *T_END = NULL;

    switch (strtol(argv[2], NULL, 10))
    {
    case 1:
        T_INIT = "2018-01-01T00:00:00";
        T_END = "2018-12-31T00:00:00";
        break;
    case 2:
        T_INIT = "2017-01-01T00:00:00";
        T_END = "2018-12-31T00:00:00";
        break;
    case 4:
        T_INIT = "2015-01-01T00:00:00";
        T_END = "2018-12-31T00:00:00";
        break;
    case 8:
        T_INIT = "2011-01-01T00:00:00";
        T_END = "2018-12-31T00:00:00";
        break;
    default:
        fprintf(stderr, "Invalid option.\n");
        return EXIT_FAILURE;
        break;
    }

    // printf("Loading...\n");
    printf("n_files,n_threads,t_rdfiles,s_training,e_training,s_prediction,e_prediction,rmse,t_total\n");
    // printf("n_files,n_threads,\n");

    DataSegment ds;

    // ----------------------- data segment ----------------------
    ds.k = 20;                                  // Interval size
    ds.win_size = (ds.k * 2) + 1;               // Window size
    ds.win_size_interpolation = (ds.k * 2) - 1; // Maximum size of interpolation range
    ds.num_Na = 10;                             // Minimum number of neighbors
    ds.num_thread = strtol(argv[1], NULL, 10);
    ds.argc = argc - 3;
    ds.indice_generic = 0;

    printf("%i,%i,", ds.argc, ds.num_thread);
    // ------------------------- rd file -------------------------
    GET_START;
    NetCDF *file = create_struct(&ds, &argv[3]);
    // printf("create_struct ");
    GET_END;

    if (!file)
    {
        fprintf(stderr, "Failed to create structures.\n");
        return EXIT_FAILURE;
    }

    // ----------------------- data segment ----------------------
    ds.start_training = binary_search(file, convert_time(TRAINING_INIT(T_INIT))) + ds.k;
    ds.end_training = binary_search(file, convert_time(TRAINING_END(T_END)));
    ds.start_prediction = binary_search(file, convert_time(PREDICTION_INIT));
    ds.end_prediction = binary_search(file, convert_time(PREDICTION_END)) - ds.k;

    // printf("start_training = %i | end_training = %i | start_prediction = %i | end_prediction = %i\n",
    printf("%i,%i,%i,%i,",
           ds.start_training,
           ds.end_training,
           ds.start_prediction,
           ds.end_prediction);

    // ----------------------- pre process -----------------------
    // GET_START;
    // printf("name - ");
    // GET_END;
    analyze_data(file, &ds, count_invalid_values);
    // analyze_data(file, &ds, print_info_percentage);
    // analyze_data(file, &ds, print_data_values);
    analyze_data(file, &ds, interpolation_values);
    analyze_data(file, &ds, count_invalid_values);
    // analyze_data(file, &ds, print_info_percentage);
    analyze_data(file, &ds, count_valid_window);
    // for (int i = 0; i < ds.argc; i++)
    //     printf("file %s - num_win_valid_prediction: %i | num_win_valid_prediction: %i \n",
    //            argv[i + 2], file[i].var[1].num_win_valid_training, file[i].var[1].num_win_valid_prediction);

    // printf("file->dim->len: %i\n", file->dim->len);
    // printf("file->var->invalid_count: %i\n", file->var[1].invalid_count);
    // printf("win_Na: %i\n",
    // (int)ceil((double)(ds.num_Na * (ds.end_training - ds.start_training)) /
    // ((ds.end_training - ds.start_training) - file->var[1].invalid_count)));
    // (int)ceil((double)(min_validos * tamanho_total) / validos);
    // ds.win_Na = ;

    // ------------------------- process -------------------------
    GET_START;
    // printf("Data exhaustive_processing_independent: \n");
    // processing_data(file, &ds, exhaustive_processing_independent);
    // printf("Data exhaustive_processing_dependent: \n");
    // processing_data(file, &ds, exhaustive_processing_dependent);
    // printf("Data partial_processing_dependent: \n");
    // processing_data(file, &ds, partial_processing_dependent);
    // printf("Data partial_processing_dependent_2: \n");
    // processing_data(file, &ds, partial_processing_dependent_2);
    // printf("Data partial_processing_dependent_3: \n");
    processing_data(file, &ds, partial_processing_dependent_3);
    // printf("Data raw_exhaustive_processing_dependent: \n");
    // processing_data(file, &ds, raw_exhaustive_processing_dependent);

    // ------------------------- parallel ------------------------
    // printf("Data exhaustive_processing_dependent_parallel: %i threads\n", ds.num_thread);
    // processing_data(file, &ds, exhaustive_processing_dependent_parallel);
    // printf("Data partial_processing_dependent_3_threaded: %i threads\n", ds.num_thread);
    // processing_data(file, &ds, partial_processing_dependent_3_threaded);
    GET_END;
    // ------------------------- wr file -------------------------
    // write_file(file, argv[0]);
    /*
     */

    // ----------------------- free memory -----------------------
    deallocate_memory(file, ds.argc);
    file = NULL;

    // Finalizing the NetCDF
    nc_finalize();
    return EXIT_SUCCESS;
}
