#include "process.h"
#include "randw.h"
#include "kdtree.h"

void processing_data(NetCDF *file, DataSegment *ds, process_func func)
{
    for (int i = 0; i < (ds->argc); i++)
    {
        if (file == NULL || file[i].var == NULL)
        {
            printf("Application(processing_data): No data in file %i.\n", (i + 1));
            return;
        }
    }

    func(file, ds); // Call the processing function
}

double monache_metric(Variable *var, DataSegment *ds, int forecast, int analog, int i)
{
    double sum = 0.0;

    switch (var->type)
    {
        MONACHE(NC_BYTE);
        MONACHE(NC_CHAR);
        MONACHE(NC_SHORT);
        MONACHE(NC_INT);
        MONACHE(NC_FLOAT);
        MONACHE(NC_DOUBLE);
        MONACHE(NC_UBYTE);
        MONACHE(NC_USHORT);
        MONACHE(NC_UINT);
        MONACHE(NC_INT64);
        MONACHE(NC_UINT64);
    }

    return isnan(sum) ? NAN : sqrt(sum);
}

double monache_metric_super_window(NetCDF *file, DataSegment *ds, int forecast, int analog, int i)
{
    double sum = 0.0;

    for (int f = 0; f < (ds->argc); f++) // Soma sobre séries temporais
    {
        switch (file[f].var[i].type)
        {
            MONACHESW(NC_BYTE);
            MONACHESW(NC_CHAR);
            MONACHESW(NC_SHORT);
            MONACHESW(NC_INT);
            MONACHESW(NC_FLOAT);
            MONACHESW(NC_DOUBLE);
            MONACHESW(NC_UBYTE);
            MONACHESW(NC_USHORT);
            MONACHESW(NC_UINT);
            MONACHESW(NC_INT64);
            MONACHESW(NC_UINT64);
        }
    }

    return isnan(sum) ? NAN : sqrt(sum);
    // return isnan(sum) ? NAN : sum;
}

// Function to compare distances for heap
int compare_closest_point_ord_const(const void *x, const void *y)
{
    ClosestPoint *point1 = (ClosestPoint *)x;
    ClosestPoint *point2 = (ClosestPoint *)y;

    if (point1->distance < point2->distance)
        return 1;
    if (point1->distance > point2->distance)
        return -1;
    return 0;
}

void recreate_data(NetCDF *file, DataSegment *ds, ClosestPoint *closest, int f_count, int n)
{
    int count = 0;
    unsigned int indice = f_count;
    double sum_values = 0;

    // Verifique se os ponteiros são válidos
    if (!file->var[n].data || !file->var[n].created_data)
    {
        fprintf(stderr, "Dados ou memória criada estão nulos para var[%d]\n", n);
        return;
    }

    // printf("IT: %i, ID: %i\t", f_count, indice);
    switch (file->var[n].type)
    {
        REC_DATA(NC_BYTE);
        REC_DATA(NC_CHAR);
        REC_DATA(NC_SHORT);
        REC_DATA(NC_INT);
        REC_DATA(NC_FLOAT);
        REC_DATA(NC_DOUBLE);
        REC_DATA(NC_UBYTE);
        REC_DATA(NC_USHORT);
        REC_DATA(NC_UINT);
        REC_DATA(NC_INT64);
        REC_DATA(NC_UINT64);
    }
    // printf("IT: %i, count: %i\t", f_count, count);
}

void calculate_rmse(NetCDF *file, DataSegment *ds, int n)
{
    double sum_error = 0;
    int count = 0, ii = 0;

    switch (file->var[n].type)
    {
        CALC_RMSE(NC_BYTE);
        CALC_RMSE(NC_CHAR);
        CALC_RMSE(NC_SHORT);
        CALC_RMSE(NC_INT);
        CALC_RMSE(NC_FLOAT);
        CALC_RMSE(NC_DOUBLE);
        CALC_RMSE(NC_UBYTE);
        CALC_RMSE(NC_USHORT);
        CALC_RMSE(NC_UINT);
        CALC_RMSE(NC_INT64);
        CALC_RMSE(NC_UINT64);
    }

    file->var[n].rmse = sqrt(sum_error / count);
}

/* Exhaustive is the same Brute Force(bf)*/
void exhaustive_processing_independent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    predicted_file = &file[0];
    predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window = true, f_is_valid_last_win = true;

            // printf("length: %i\n", length);

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            // !predicted_file->var[n].created_data ? printf("created_data é nulo...") : printf("segue o baile!!!\n");
            // printf("passou aqui!!!");

            f_is_valid_last_win = false;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                int flag_break;
                int count_test = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                if (f_is_valid_last_win)
                {
                    int j = ds->k * 2;
                    flag_break = 0;

                    switch (predictor_file->var[n].type)
                    {
                        F_IFNAN(NC_BYTE);
                        F_IFNAN(NC_CHAR);
                        F_IFNAN(NC_SHORT);
                        F_IFNAN(NC_INT);
                        F_IFNAN(NC_FLOAT);
                        F_IFNAN(NC_DOUBLE);
                        F_IFNAN(NC_UBYTE);
                        F_IFNAN(NC_USHORT);
                        F_IFNAN(NC_UINT);
                        F_IFNAN(NC_INT64);
                        F_IFNAN(NC_UINT64);
                    }

                    if (flag_break == -1)
                        break;
                }
                else
                {
                    flag_break = 1;

                    // Check if the window is valid
                    for (int j = 0; j < ds->win_size; j++)
                    {
                        switch (predictor_file->var[n].type)
                        {
                            F_IFNAN(NC_BYTE);
                            F_IFNAN(NC_CHAR);
                            F_IFNAN(NC_SHORT);
                            F_IFNAN(NC_INT);
                            F_IFNAN(NC_FLOAT);
                            F_IFNAN(NC_DOUBLE);
                            F_IFNAN(NC_UBYTE);
                            F_IFNAN(NC_USHORT);
                            F_IFNAN(NC_UINT);
                            F_IFNAN(NC_INT64);
                            F_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            break;
                    }
                }

                if (flag_break == -1)
                    continue;

                f_valid_count++;
                f_is_valid_last_win = true;

                /* ---------- Training period begins ---------- */

                bool a_is_valid_last_win, a_is_valid_window;
                int valid_count = 0;
                int analog = 0;
                int found = 0;

                a_is_valid_last_win = false;

                /**/
                for (analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    // printf("passou aqui: %i!!!\n", analog);
                    a_is_valid_window = true;

                    if (a_is_valid_last_win)
                    {
                        int j = ds->k * 2;
                        flag_break = 0;
                        switch (predictor_file->var[n].type)
                        {
                            A_IFNAN(NC_BYTE);
                            A_IFNAN(NC_CHAR);
                            A_IFNAN(NC_SHORT);
                            A_IFNAN(NC_INT);
                            A_IFNAN(NC_FLOAT);
                            A_IFNAN(NC_DOUBLE);
                            A_IFNAN(NC_UBYTE);
                            A_IFNAN(NC_USHORT);
                            A_IFNAN(NC_UINT);
                            A_IFNAN(NC_INT64);
                            A_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            continue;
                    }
                    else
                    {
                        flag_break = 1;
                        // Check if the window is valid
                        for (int j = 0; j < ds->win_size; j++)
                        {
                            switch (predictor_file->var[n].type)
                            {
                                A_IFNAN(NC_BYTE);
                                A_IFNAN(NC_CHAR);
                                A_IFNAN(NC_SHORT);
                                A_IFNAN(NC_INT);
                                A_IFNAN(NC_FLOAT);
                                A_IFNAN(NC_DOUBLE);
                                A_IFNAN(NC_UBYTE);
                                A_IFNAN(NC_USHORT);
                                A_IFNAN(NC_UINT);
                                A_IFNAN(NC_INT64);
                                A_IFNAN(NC_UINT64);
                            }

                            if (flag_break == -1)
                                break;
                        }
                    }

                    if (flag_break == -1)
                        continue;

                    // Calculate distance only for valid windows
                    if (a_is_valid_window)
                    {
                        double distance = monache_metric(&predictor_file->var[n],
                                                         ds,
                                                         forecast,
                                                         analog,
                                                         n);

                        if (!isnan((double)distance))
                        {
                            if (found < ds->num_Na)
                            {
                                closest[found].window_index = analog;
                                closest[found].distance = distance;
                                found++;
                                if (found == ds->num_Na)
                                    qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                            else if (distance < closest[0].distance)
                            {
                                closest[0].window_index = analog;
                                closest[0].distance = distance;
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                        }

                        a_is_valid_last_win = true;
                        valid_count++;
                        a_count++;
                    }
                }
                // printf("a_count total: %i\n", a_count);

                printf("------------------------------------------------------------------\n");
                printf("Position: %i\n", forecast);
                for (int i = 0; i < found; i++)
                {
                    printf("| P%i D: %.2f ", i, closest[i].distance);
                    // printf("| P%i D: %.2f ", i, ((float *)predictor_file->var[n].data)[closest[i].window_index]);
                }
                printf("\n");
                printf("------------------------------------------------------------------\n");

                recreate_data(predicted_file, ds, closest, f_count, n);

                free(closest);
                // // Sort distances
                // qsort(distances, valid_count, sizeof(WindowDistance), compare_distances);
                f_count++;
            }
            // printf("f_count: %i\n", f_count);
            // printf("a_count: %.2lf\n", (double)a_count / f_count);
            // printf("a_count total: %i\n", a_count);
        }
        calculate_rmse(predicted_file, ds, n);
        printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
    }
}

void exhaustive_processing_dependent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    predicted_file = &file[0];
    predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window = true, f_is_valid_last_win = true;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            f_is_valid_last_win = false;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                int flag_break;
                int count_test = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                if (f_is_valid_last_win)
                {
                    int j = ds->k * 2;
                    flag_break = 0;

                    switch (predictor_file->var[n].type)
                    {
                        F_IFNAN(NC_BYTE);
                        F_IFNAN(NC_CHAR);
                        F_IFNAN(NC_SHORT);
                        F_IFNAN(NC_INT);
                        F_IFNAN(NC_FLOAT);
                        F_IFNAN(NC_DOUBLE);
                        F_IFNAN(NC_UBYTE);
                        F_IFNAN(NC_USHORT);
                        F_IFNAN(NC_UINT);
                        F_IFNAN(NC_INT64);
                        F_IFNAN(NC_UINT64);
                    }

                    if (flag_break == -1)
                        break;
                }
                else
                {
                    flag_break = 1;

                    // Check if the window is valid
                    for (int j = 0; j < ds->win_size; j++)
                    {
                        switch (predictor_file->var[n].type)
                        {
                            F_IFNAN(NC_BYTE);
                            F_IFNAN(NC_CHAR);
                            F_IFNAN(NC_SHORT);
                            F_IFNAN(NC_INT);
                            F_IFNAN(NC_FLOAT);
                            F_IFNAN(NC_DOUBLE);
                            F_IFNAN(NC_UBYTE);
                            F_IFNAN(NC_USHORT);
                            F_IFNAN(NC_UINT);
                            F_IFNAN(NC_INT64);
                            F_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            break;
                    }
                }

                if (flag_break == -1)
                    continue;

                f_valid_count++;
                f_is_valid_last_win = true;

                /* ---------- Training period begins ---------- */

                bool a_is_valid_last_win, a_is_valid_window;
                int valid_count = 0;
                int analog = 0;
                int found = 0;

                a_is_valid_last_win = false;

                /**/
                for (analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    // printf("passou aqui: %i!!!\n", analog);
                    a_is_valid_window = true;

                    if (a_is_valid_last_win)
                    {
                        int j = ds->k * 2;
                        flag_break = 0;
                        switch (predictor_file->var[n].type)
                        {
                            A_IFNAN(NC_BYTE);
                            A_IFNAN(NC_CHAR);
                            A_IFNAN(NC_SHORT);
                            A_IFNAN(NC_INT);
                            A_IFNAN(NC_FLOAT);
                            A_IFNAN(NC_DOUBLE);
                            A_IFNAN(NC_UBYTE);
                            A_IFNAN(NC_USHORT);
                            A_IFNAN(NC_UINT);
                            A_IFNAN(NC_INT64);
                            A_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            continue;
                    }
                    else
                    {
                        flag_break = 1;
                        // Check if the window is valid
                        for (int j = 0; j < ds->win_size; j++)
                        {
                            switch (predictor_file->var[n].type)
                            {
                                A_IFNAN(NC_BYTE);
                                A_IFNAN(NC_CHAR);
                                A_IFNAN(NC_SHORT);
                                A_IFNAN(NC_INT);
                                A_IFNAN(NC_FLOAT);
                                A_IFNAN(NC_DOUBLE);
                                A_IFNAN(NC_UBYTE);
                                A_IFNAN(NC_USHORT);
                                A_IFNAN(NC_UINT);
                                A_IFNAN(NC_INT64);
                                A_IFNAN(NC_UINT64);
                            }

                            if (flag_break == -1)
                                break;
                        }
                    }

                    if (flag_break == -1)
                        continue;

                    // Calculate distance only for valid windows
                    if (a_is_valid_window)
                    {
                        double distance = monache_metric_super_window(predictor_file,
                                                                      ds,
                                                                      forecast,
                                                                      analog,
                                                                      n);

                        if (!isnan((double)distance))
                        {
                            if (found < ds->num_Na)
                            {
                                closest[found].window_index = analog;
                                closest[found].distance = distance;
                                found++;
                                if (found == ds->num_Na)
                                    qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                            else if (distance < closest[0].distance)
                            {
                                closest[0].window_index = analog;
                                closest[0].distance = distance;
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                        }

                        a_is_valid_last_win = true;
                        valid_count++;
                        a_count++;
                    }
                }

                // printf("------------------------------------------------------------------\n");
                // printf("Position: %i\n", forecast);
                // for (int i = 0; i < found; i++)
                // {
                //     printf("| P%i D: %.2f ", i, closest[i].distance);
                //     // printf("| P%i D: %.2f ", i, ((float *)predictor_file->var[n].data)[closest[i].window_index]);
                // }
                // printf("\n");
                // printf("------------------------------------------------------------------\n");

                recreate_data(predicted_file, ds, closest, f_count, n);

                free(closest);
                f_count++;
            }
            // printf("f_count: %i\n", f_count);
            // printf("a_count: %.2lf\n", (double)a_count / f_count);
            // printf("a_count total: %i\n", a_count);
        }
        calculate_rmse(predicted_file, ds, n);
        // printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
        printf("%.3lf,", predicted_file->var[n].rmse);
    }
}

void raw_exhaustive_processing_dependent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    predicted_file = &file[0];
    predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window = true, f_is_valid_last_win = true;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }

            f_is_valid_last_win = false;

            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                int count_test = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                /* ---------- Training period begins ---------- */
                int valid_count = 0;
                int analog = 0;
                int found = 0;

                for (analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    // Calculate distance only for valid windows
                    double distance = monache_metric_super_window(predictor_file,
                                                                  ds,
                                                                  forecast,
                                                                  analog,
                                                                  n);

                    if (!isnan((double)distance))
                    {
                        if (found < ds->num_Na)
                        {
                            closest[found].window_index = analog;
                            closest[found].distance = distance;
                            found++;
                            if (found == ds->num_Na)
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                        }
                        else if (distance < closest[0].distance)
                        {
                            closest[0].window_index = analog;
                            closest[0].distance = distance;
                            qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                        }
                    }

                    valid_count++;
                    a_count++;
                }
                // printf("a_count total: %i\n", a_count);

                if (found != 0)
                {
                    printf("------------------------------------------------------------------\n");
                    printf("Position: %i\n", forecast);
                    for (int i = 0; i < found; i++)
                    {
                        printf("| P%i D: %.2f ", i, closest[i].distance);
                        // printf("| P%i D: %.2f ", i, ((float *)predictor_file->var[n].data)[closest[i].window_index]);
                    }
                    printf("\n");
                    printf("------------------------------------------------------------------\n");
                    recreate_data(predicted_file, ds, closest, f_count, n);
                    f_count++;
                }

                free(closest);
            }
            // printf("f_count: %i\n", f_count);
            // printf("a_count: %.2lf\n", (double)a_count / f_count);
            // printf("a_count total: %i\n", a_count);
        }
        calculate_rmse(predicted_file, ds, n);
        printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
    }
}
/*
void partial_processing_dependent(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or mores

    // Start measuring time
    struct timeval begin, end;
    long seconds = 0;
    long microseconds = 0;
    double elapsed = 0;

    predicted_file = &file[0];
    predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window, f_is_valid_last_win;
            int analog = 0;
            KDTree *root = NULL;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                printf("Warning: Check partial_processing_dependent->ALLOCATE_MEMORY_REC_DATA.\n");
                break;
            }

            f_is_valid_last_win = false;

            for (analog = ds->start_training; analog <= ds->end_training; analog++)
            {
                switch (predictor_file->var[n].type)
                {
                    IFNAN_KDTREE(NC_BYTE);
                    IFNAN_KDTREE(NC_CHAR);
                    IFNAN_KDTREE(NC_SHORT);
                    IFNAN_KDTREE(NC_INT);
                    IFNAN_KDTREE(NC_FLOAT);
                    IFNAN_KDTREE(NC_DOUBLE);
                    IFNAN_KDTREE(NC_UBYTE);
                    IFNAN_KDTREE(NC_USHORT);
                    IFNAN_KDTREE(NC_UINT);
                    IFNAN_KDTREE(NC_INT64);
                    IFNAN_KDTREE(NC_UINT64);
                default:
                    printf("Warning: Check partial_processing_dependent->IS_NAN.\n");
                    break;
                }
            }

            // Check if the tree is balanced
            if (is_kdtree_balanced(root))
                printf("The k-d tree is balanced.\n");
            else
                printf("The k-d tree is not balanced.\n");

            // Print some additional information
            printf("Tree height: %d\n", get_tree_height(root));
            printf("Total nodes: %d\n", count_nodes(root));

            int count_kdtree = 0;
            gettimeofday(&begin, 0);
            // printf("diff: %i\n", ds->end_prediction - ds->start_prediction);
            // check_tree(root, 0);
            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                // printf("count_kdtree: %i\n", count_kdtree);

                int valid_count = 0;
                int count_test = 0;
                int flag_break;

                if (f_is_valid_last_win)
                {
                    int j = ds->k * 2;
                    flag_break = 0;

                    switch (predictor_file->var[n].type)
                    {
                        F_IFNAN(NC_BYTE);
                        F_IFNAN(NC_CHAR);
                        F_IFNAN(NC_SHORT);
                        F_IFNAN(NC_INT);
                        F_IFNAN(NC_FLOAT);
                        F_IFNAN(NC_DOUBLE);
                        F_IFNAN(NC_UBYTE);
                        F_IFNAN(NC_USHORT);
                        F_IFNAN(NC_UINT);
                        F_IFNAN(NC_INT64);
                        F_IFNAN(NC_UINT64);
                    }

                    if (flag_break == -1)
                        continue;
                }
                else
                {
                    flag_break = 1;

                    // Check if the window is valid
                    for (int j = 0; j < ds->win_size; j++)
                    {
                        switch (predictor_file->var[n].type)
                        {
                            F_IFNAN(NC_BYTE);
                            F_IFNAN(NC_CHAR);
                            F_IFNAN(NC_SHORT);
                            F_IFNAN(NC_INT);
                            F_IFNAN(NC_FLOAT);
                            F_IFNAN(NC_DOUBLE);
                            F_IFNAN(NC_UBYTE);
                            F_IFNAN(NC_USHORT);
                            F_IFNAN(NC_UINT);
                            F_IFNAN(NC_INT64);
                            F_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            break;
                    }
                }

                if (flag_break == -1)
                    continue;

                f_valid_count++;
                f_is_valid_last_win = true;

                int found = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                search_closest_points(root, &predictor_file->var[n], ds, closest, forecast, 0, &found);
                // search_closest_points_super_window(root, predictor_file, ds, closest, forecast, 0, n, &found);

                // printf("step 10\n");

                printf("------------------------------------------------------------------\n");
                printf("Position: %i\n", forecast);
                for (int i = 0; i < found; i++)
                {
                    printf("| P%i D: %.2f ", i, closest[i].distance);
                }
                printf("\n");
                printf("------------------------------------------------------------------\n");

                recreate_data(predicted_file, ds, closest, f_count, n);

                count_kdtree++;
                free(closest);
                f_count++;
            }

            // printf("f_count: %i\n", f_count);
            // printf("a_count: %.2lf\n", (double)a_count / f_count);
            // printf("a_count total: %i\n", a_count);

            gettimeofday(&end, 0); // Stop measuring time and calculate the elapsed time
            seconds = end.tv_sec - begin.tv_sec;
            microseconds = end.tv_usec - begin.tv_usec;
            elapsed = seconds + microseconds * 1e-6;
            printf("Time measured - search_closest_points: %.3f seconds.\n", elapsed);

            deallocate_kdtree(root);
            calculate_rmse(predicted_file, ds, n);
            printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
        }
    }
}

void partial_processing_dependent_2(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or mores

    // Start measuring time
    struct timeval begin, end;
    long seconds = 0;
    long microseconds = 0;
    double elapsed = 0;

    predicted_file = &file[0];
    predictor_file = &file[1];

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window, f_is_valid_last_win;
            int analog = 0;

            // Initialize variables for the balanced KD-tree approach
            int total_training_points = ds->end_training - ds->start_training + 1;
            int *training_indices = (int *)malloc(total_training_points * sizeof(int));
            int valid_training_points = 0;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                printf("Warning: Check partial_processing_dependent->ALLOCATE_MEMORY_REC_DATA.\n");
                break;
            }

            f_is_valid_last_win = false;

            // First collect valid training points
            for (analog = ds->start_training; analog <= ds->end_training; analog++)
            {
                bool is_valid = true;

                // Check if this training point is valid (not NaN)
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                {
                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(((float *)predictor_file->var[n].data)[analog - ds->k + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                case NC_DOUBLE:
                {
                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(((double *)predictor_file->var[n].data)[analog - ds->k + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                    // Add other types similarly
                }

                // If valid, add to our array of training indices
                if (is_valid)
                {
                    training_indices[valid_training_points] = analog;
                    valid_training_points++;
                    a_count++;
                }
            }

            // Now build a balanced KD-tree from all valid training points at once
            KDTree *root = NULL;
            if (valid_training_points > 0)
            {
                root = build_balanced_kdtree(training_indices, valid_training_points, &predictor_file->var[n], ds, 0);
            }

            // Free the temporary array
            free(training_indices);

            // Check if the tree is balanced
            if (is_kdtree_balanced(root))
                printf("The k-d tree is balanced.\n");
            else
                printf("The k-d tree is not balanced.\n");

            // Print diagnostic information
            diagnose_tree_balance(root);

            int count_kdtree = 0;
            gettimeofday(&begin, 0);

            // Rest of your code remains the same
            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                int valid_count = 0;
                int count_test = 0;
                int flag_break;

                if (f_is_valid_last_win)
                {
                    int j = ds->k * 2;
                    flag_break = 0;

                    switch (predictor_file->var[n].type)
                    {
                        F_IFNAN(NC_BYTE);
                        F_IFNAN(NC_CHAR);
                        F_IFNAN(NC_SHORT);
                        F_IFNAN(NC_INT);
                        F_IFNAN(NC_FLOAT);
                        F_IFNAN(NC_DOUBLE);
                        F_IFNAN(NC_UBYTE);
                        F_IFNAN(NC_USHORT);
                        F_IFNAN(NC_UINT);
                        F_IFNAN(NC_INT64);
                        F_IFNAN(NC_UINT64);
                    }

                    if (flag_break == -1)
                        continue;
                }
                else
                {
                    flag_break = 1;

                    // Check if the window is valid
                    for (int j = 0; j < ds->win_size; j++)
                    {
                        switch (predictor_file->var[n].type)
                        {
                            F_IFNAN(NC_BYTE);
                            F_IFNAN(NC_CHAR);
                            F_IFNAN(NC_SHORT);
                            F_IFNAN(NC_INT);
                            F_IFNAN(NC_FLOAT);
                            F_IFNAN(NC_DOUBLE);
                            F_IFNAN(NC_UBYTE);
                            F_IFNAN(NC_USHORT);
                            F_IFNAN(NC_UINT);
                            F_IFNAN(NC_INT64);
                            F_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            break;
                    }
                }

                if (flag_break == -1)
                    continue;

                f_valid_count++;
                f_is_valid_last_win = true;

                int found = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                // Use the search function with the balanced tree
                search_closest_points_super_window(root, predictor_file, ds, closest, forecast, 0, n, &found);

                // Rest of your processing
                recreate_data(predicted_file, ds, closest, f_count, n);

                count_kdtree++;
                free(closest);
                f_count++;
            }

            printf("f_count: %i\n", f_count);

            gettimeofday(&end, 0);
            seconds = end.tv_sec - begin.tv_sec;
            microseconds = end.tv_usec - begin.tv_usec;
            elapsed = seconds + microseconds * 1e-6;
            printf("Time measured - search_closest_points: %.3f seconds.\n", elapsed);

            deallocate_kdtree(root);
            calculate_rmse(predicted_file, ds, n);
            printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
        }
    }
}
*/
void partial_processing_dependent_3(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    // Start measuring time
    struct timeval begin, end;
    long seconds = 0;
    long microseconds = 0;
    double elapsed = 0;

    predicted_file = &file[0];
    predictor_file = &file[1];

    // Create a node pool for efficient memory management across iterations
    NodePool *global_pool = create_node_pool();

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window, f_is_valid_last_win;
            int analog = 0;

            // Reset the node pool for this iteration
            reset_node_pool(global_pool);

            // Initialize variables for the balanced KD-tree approach
            int total_training_points = ds->end_training - ds->start_training + 1;
            int *training_indices = (int *)malloc(total_training_points * sizeof(int));
            int valid_training_points = 0;

            switch (predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            default:
                printf("Warning: Check partial_processing_dependent_3->ALLOCATE_MEMORY_REC_DATA.\n");
                break;
            }

            f_is_valid_last_win = false;

            // First collect valid training points with optimized type-specific validation
            for (analog = ds->start_training; analog <= ds->end_training; analog++)
            {
                bool is_valid = true;

                // Check if this training point is valid (not NaN)
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                {
                    float *data = (float *)predictor_file->var[n].data;
                    int window_offset = analog - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                case NC_DOUBLE:
                {
                    double *data = (double *)predictor_file->var[n].data;
                    int window_offset = analog - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                    // Add other types similarly
                }

                // If valid, add to our array of training indices
                if (is_valid)
                {
                    training_indices[valid_training_points] = analog;
                    valid_training_points++;
                    a_count++;
                }
            }

            // Build a balanced KD-tree from all valid training points at once
            KDTree *root = NULL;
            if (valid_training_points > 0)
            {
                // Use the build_balanced_kdtree function with node pool
                root = build_balanced_kdtree(training_indices, valid_training_points,
                                             &predictor_file->var[n], ds, 0, global_pool);
            }

            // Free the temporary array
            free(training_indices);

// Print tree diagnostics in debug mode only
#ifdef DEBUG
            if (is_kdtree_balanced(root))
                printf("The k-d tree is balanced.\n");
            else
                printf("The k-d tree is not balanced. Rebalancing...\n");

            diagnose_tree_balance(root);

            // Rebalance if needed
            if (!is_kdtree_balanced(root))
            {
                root = rebalance_kdtree(root, &predictor_file->var[n], ds);
                printf("Tree after rebalancing:\n");
                diagnose_tree_balance(root);
            }
#endif

            int count_kdtree = 0;
            gettimeofday(&begin, 0);

            // Pre-allocate memory for batch processing
            ClosestPoint **all_closest_points = NULL;
            int num_valid_forecasts = 0;
            int *valid_forecasts = NULL;

            // First pass: count valid forecast points
            for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
            {
                bool is_valid = true;

                // Check if this forecast point is valid
                switch (predictor_file->var[n].type)
                {
                case NC_FLOAT:
                {
                    float *data = (float *)predictor_file->var[n].data;
                    int window_offset = forecast - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                case NC_DOUBLE:
                {
                    double *data = (double *)predictor_file->var[n].data;
                    int window_offset = forecast - ds->k;

                    for (int j = 0; j < ds->win_size; j++)
                    {
                        if (isnan(data[window_offset + j]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    break;
                }
                    // Add other types similarly
                }

                if (is_valid)
                    num_valid_forecasts++;
            }

            // Allocate memory for valid forecasts and closest points
            if (num_valid_forecasts > 0)
            {
                valid_forecasts = (int *)malloc(num_valid_forecasts * sizeof(int));
                all_closest_points = (ClosestPoint **)malloc(num_valid_forecasts * sizeof(ClosestPoint *));

                // Second pass: collect valid forecasts
                int valid_idx = 0;
                for (int forecast = ds->start_prediction; forecast <= ds->end_prediction; forecast++)
                {
                    bool is_valid = true;

                    // Check if this forecast point is valid (same as above)
                    switch (predictor_file->var[n].type)
                    {
                    case NC_FLOAT:
                    {
                        float *data = (float *)predictor_file->var[n].data;
                        int window_offset = forecast - ds->k;

                        for (int j = 0; j < ds->win_size; j++)
                        {
                            if (isnan(data[window_offset + j]))
                            {
                                is_valid = false;
                                break;
                            }
                        }
                        break;
                    }
                    case NC_DOUBLE:
                    {
                        double *data = (double *)predictor_file->var[n].data;
                        int window_offset = forecast - ds->k;

                        for (int j = 0; j < ds->win_size; j++)
                        {
                            if (isnan(data[window_offset + j]))
                            {
                                is_valid = false;
                                break;
                            }
                        }
                        break;
                    }
                        // Add other types similarly
                    }

                    if (is_valid)
                    {
                        valid_forecasts[valid_idx] = forecast;
                        all_closest_points[valid_idx] = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));
                        valid_idx++;
                    }
                }

                // Batch process all valid forecasts
                if (valid_idx > 0)
                {
                    // Process in batches for better cache utilization
                    int batch_size = 100; // Adjust based on your system's cache size
                    for (int batch_start = 0; batch_start < valid_idx; batch_start += batch_size)
                    {
                        int batch_end = batch_start + batch_size;
                        if (batch_end > valid_idx)
                            batch_end = valid_idx;

                        for (int i = batch_start; i < batch_end; i++)
                        {
                            int found = 0;
                            int forecast = valid_forecasts[i];

                            // Initialize current best distance for early termination
                            ds->current_best_distance = INFINITY;

                            // Search for nearest neighbors using the balanced tree
                            // search_closest_points_super_window(root, predictor_file, ds,
                            //                                    all_closest_points[i], forecast, 0, n, &found);
                            search_closest_points(root, &predictor_file->var[n], ds,
                                                  all_closest_points[i], forecast, 0, &found);
                        }
                    }
                }

                // Process results and recreate data
                for (int i = 0; i < valid_idx; i++)
                {
                    recreate_data(predicted_file, ds, all_closest_points[i], f_count, n);
                    free(all_closest_points[i]);
                    f_count++;
                    count_kdtree++;
                }

                // Free allocated memory
                free(valid_forecasts);
                free(all_closest_points);
            }

            // printf("f_count: %d\n", f_count);

            gettimeofday(&end, 0);
            seconds = end.tv_sec - begin.tv_sec;
            microseconds = end.tv_usec - begin.tv_usec;
            elapsed = seconds + microseconds * 1e-6;
            // printf("Time measured - search_closest_points: %.3f seconds.\n", elapsed);
            printf("%.3f,", elapsed);

            // We don't need to deallocate the tree nodes individually
            // since they're managed by the node pool
            calculate_rmse(predicted_file, ds, n);
            // printf("RMSE: %.3lf\n", predicted_file->var[n].rmse);
            printf("%.3lf,", predicted_file->var[n].rmse);
        }
    }

    // Free the global node pool at the end
    free_node_pool(global_pool);
}

void exhaustive_processing_dependent_parallel(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    ThreadData thread_data[ds->num_thread];
    pthread_t threads[ds->num_thread];

    ds->predicted_file = &file[0];
    ds->predictor_file = &file[1];

    for (int n = 1; n - 1 < ds->predictor_file->nvars - 13; n++)
    {
        if (ds->predictor_file->var[n].invalid_percentage <= (double)15 &&
            ds->predictor_file->var[n].invalid_percentage != (double)0)
        {
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            switch (ds->predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }
        }
    }

    for (int t = 0; t < ds->num_thread; t++)
    {
        thread_data[t].thread_id = t;
        thread_data[t].ds = ds;
        thread_data[t].forecast = 0;
        thread_data[t].analog = 0;

        pthread_create(&threads[t], NULL, thread_exhaustive_processing_dependent, (void *)&thread_data[t]);
    }

    for (int t = 0; t < ds->num_thread; t++)
        pthread_join(threads[t], NULL);

    for (int n = 1; n - 1 < file[0].nvars - 13; n++)
    {
        calculate_rmse(ds->predicted_file, ds, n);
        // printf("RMSE: %.3lf\n", ds->predicted_file->var[n].rmse);
        printf("%.3lf,", ds->predicted_file->var[n].rmse);
    }
}

void *thread_exhaustive_processing_dependent(void *arg)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more
    ThreadData *thread = (ThreadData *)arg;
    DataSegment *ds = (DataSegment *)thread->ds;
    predicted_file = ds->predicted_file;
    predictor_file = ds->predictor_file;

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_id = thread->thread_id;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog

            bool f_is_valid_window;

            /* ---------- Predicted period begins ---------- */

            for (int forecast = ds->start_prediction + thread->thread_id; forecast <= ds->end_prediction; forecast += ds->num_thread)
            {
                int count_test = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                f_is_valid_window = true;

                for (int j = 0; j < ds->win_size; j++)
                {
                    switch (predictor_file->var[n].type)
                    {
                        F_IFNAN_THREAD(NC_BYTE);
                        F_IFNAN_THREAD(NC_CHAR);
                        F_IFNAN_THREAD(NC_SHORT);
                        F_IFNAN_THREAD(NC_INT);
                        F_IFNAN_THREAD(NC_FLOAT);
                        F_IFNAN_THREAD(NC_DOUBLE);
                        F_IFNAN_THREAD(NC_UBYTE);
                        F_IFNAN_THREAD(NC_USHORT);
                        F_IFNAN_THREAD(NC_UINT);
                        F_IFNAN_THREAD(NC_INT64);
                        F_IFNAN_THREAD(NC_UINT64);
                    }

                    if (!f_is_valid_window)
                        break;
                }

                if (!f_is_valid_window)
                    continue;

                f_valid_count++;

                /* ---------- Training period begins ---------- */

                bool a_is_valid_last_win, a_is_valid_window;
                int valid_count = 0;
                int analog = 0;
                int found = 0;
                int flag_break;

                a_is_valid_last_win = false;

                for (analog = ds->start_training; analog <= ds->end_training; analog++)
                {
                    // printf("passou aqui: %i!!!\n", analog);
                    a_is_valid_window = true;

                    if (a_is_valid_last_win)
                    {
                        int j = ds->k * 2;
                        flag_break = 0;
                        switch (predictor_file->var[n].type)
                        {
                            A_IFNAN(NC_BYTE);
                            A_IFNAN(NC_CHAR);
                            A_IFNAN(NC_SHORT);
                            A_IFNAN(NC_INT);
                            A_IFNAN(NC_FLOAT);
                            A_IFNAN(NC_DOUBLE);
                            A_IFNAN(NC_UBYTE);
                            A_IFNAN(NC_USHORT);
                            A_IFNAN(NC_UINT);
                            A_IFNAN(NC_INT64);
                            A_IFNAN(NC_UINT64);
                        }

                        if (flag_break == -1)
                            break;
                    }
                    else
                    {
                        flag_break = 1;
                        // Check if the window is valid
                        for (int j = 0; j < ds->win_size; j++)
                        {
                            switch (predictor_file->var[n].type)
                            {
                                A_IFNAN(NC_BYTE);
                                A_IFNAN(NC_CHAR);
                                A_IFNAN(NC_SHORT);
                                A_IFNAN(NC_INT);
                                A_IFNAN(NC_FLOAT);
                                A_IFNAN(NC_DOUBLE);
                                A_IFNAN(NC_UBYTE);
                                A_IFNAN(NC_USHORT);
                                A_IFNAN(NC_UINT);
                                A_IFNAN(NC_INT64);
                                A_IFNAN(NC_UINT64);
                            }

                            if (flag_break == -1)
                                break;
                        }
                    }

                    if (flag_break == -1)
                        continue;

                    // Calculate distance only for valid windows
                    if (a_is_valid_window)
                    {
                        double distance = monache_metric_super_window(predictor_file,
                                                                      ds,
                                                                      forecast,
                                                                      analog,
                                                                      n);

                        if (!isnan((float)distance))
                        {
                            if (found < ds->num_Na)
                            {
                                closest[found].window_index = analog;
                                closest[found].distance = distance;
                                found++;
                                if (found == ds->num_Na)
                                    qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                            else if (distance < closest[0].distance)
                            {
                                closest[0].window_index = analog;
                                closest[0].distance = distance;
                                qsort(closest, ds->num_Na, sizeof(ClosestPoint), compare_closest_point_ord_const);
                            }
                        }

                        valid_count++;
                        a_is_valid_last_win = true;
                        thread->analog++;
                    }
                }

                // printf("------------------------------------------------------------------\n");
                // printf("Position: %i\n", forecast);
                // for (int i = 0; i < found; i++)
                // {
                //     printf("| P%i D: %.2f ", i, closest[i].distance);
                //     // printf("| P%i D: %.2f ", i, ((float *)predictor_file->var[n].data)[closest[i].window_index]);
                // }
                // printf("\n");
                // printf("------------------------------------------------------------------\n");

                // printf("passou aqui!!!");

                recreate_data(predicted_file, ds, closest, f_id, n);

                free(closest);
                f_id += ds->num_thread;
                thread->forecast++;
            }
            // printf("f_count: %i\n", thread->forecast);
            // printf("a_count: %.2lf\n", (double)thread->analog / thread->forecast);
        }
    }

    pthread_exit(NULL);
}
/*
void partial_processing_dependent_3_threaded(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more

    predicted_file = &file[0];
    predictor_file = &file[1];

    // Thread-related variables
    pthread_t *threads;
    ThreadData *thread_data;

    threads = (pthread_t *)malloc(ds->num_thread * sizeof(pthread_t));
    thread_data = (ThreadData *)malloc(ds->num_thread * sizeof(ThreadData));

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            // Create a node pool for efficient memory management across iterations
            NodePool *global_pool = create_node_pool();

            // Prepare thread data
            for (int t = 0; t < ds->num_thread; t++)
            {
                thread_data[t].thread_id = t;
                thread_data[t].ds = ds;
                thread_data[t].ds->start_prediction = ds->start_prediction + t;
                thread_data[t].ds->end_prediction = ds->end_prediction;
                thread_data[t].forecast = 0;
                thread_data[t].analog = 0;
                thread_data[t].var_index = n;
                thread_data[t].global_pool = global_pool;
                thread_data[t].predicted_file = predicted_file;
                thread_data[t].predictor_file = predictor_file;
            }

            // Launch threads
            for (int t = 0; t < ds->num_thread; t++)
            {
                pthread_create(&threads[t], NULL, thread_partial_processing_dependent, (void *)&thread_data[t]);
            }

            // Wait for threads to complete
            for (int t = 0; t < ds->num_thread; t++)
            {
                pthread_join(threads[t], NULL);
            }

            // Free the global node pool
            free_node_pool(global_pool);

            // Calculate RMSE
            calculate_rmse(predicted_file, ds, n);
            printf("RMSE for variable %d: %.3lf\n", n, predicted_file->var[n].rmse);
        }
    }

    // Free thread-related resources
    free(threads);
    free(thread_data);
}

// Thread function for partial processing
void *thread_partial_processing_dependent(void *arg)
{
    ThreadData *thread = (ThreadData *)arg;
    DataSegment *ds = thread->ds;
    NetCDF *predicted_file = thread->predicted_file;
    NetCDF *predictor_file = thread->predictor_file;
    int n = thread->var_index;

    // Create a node pool for this thread
    NodePool *thread_pool = create_node_pool();

    // Initialize variables for the balanced KD-tree approach
    int total_training_points = ds->end_training - ds->start_training + 1;
    int *training_indices = (int *)malloc(total_training_points * sizeof(int));
    int valid_training_points = 0;
    int a_count = 0;

    // First collect valid training points with optimized type-specific validation
    for (int analog = ds->start_training; analog <= ds->end_training; analog++)
    {
        bool is_valid = true;

        // Check if this training point is valid (not NaN)
        switch (predictor_file->var[n].type)
        {
        case NC_FLOAT:
        {
            float *data = (float *)predictor_file->var[n].data;
            int window_offset = analog - ds->k;

            for (int j = 0; j < ds->win_size; j++)
            {
                if (isnan(data[window_offset + j]))
                {
                    is_valid = false;
                    break;
                }
            }
            break;
        }
        case NC_DOUBLE:
        {
            double *data = (double *)predictor_file->var[n].data;
            int window_offset = analog - ds->k;

            for (int j = 0; j < ds->win_size; j++)
            {
                if (isnan(data[window_offset + j]))
                {
                    is_valid = false;
                    break;
                }
            }
            break;
        }
            // Add other types similarly (same as in the non-threaded version)
        }

        // If valid, add to our array of training indices
        if (is_valid)
        {
            training_indices[valid_training_points] = analog;
            valid_training_points++;
            a_count++;
        }
    }

    // Build a balanced KD-tree from all valid training points at once
    KDTree *root = NULL;
    if (valid_training_points > 0)
    {
        // Use the build_balanced_kdtree function with node pool
        root = build_balanced_kdtree(training_indices, valid_training_points,
                                     &predictor_file->var[n], ds, 0, thread_pool);
    }

    // Free the temporary array
    free(training_indices);

    // Prepare for forecasting
    unsigned int length = (ds->end_prediction - ds->start_prediction);
    int f_count = 0;

    // Pre-allocate memory for batch processing
    ClosestPoint **all_closest_points = NULL;
    int num_valid_forecasts = 0;
    int *valid_forecasts = NULL;

    // First pass: count valid forecast points
    for (int forecast = ds->start_prediction + thread->thread_id;
         forecast <= ds->end_prediction;
         forecast += ds->num_thread)
    {
        bool is_valid = true;

        // Check if this forecast point is valid
        switch (predictor_file->var[n].type)
        {
        case NC_FLOAT:
        {
            float *data = (float *)predictor_file->var[n].data;
            int window_offset = forecast - ds->k;

            for (int j = 0; j < ds->win_size; j++)
            {
                if (isnan(data[window_offset + j]))
                {
                    is_valid = false;
                    break;
                }
            }
            break;
        }
        case NC_DOUBLE:
        {
            double *data = (double *)predictor_file->var[n].data;
            int window_offset = forecast - ds->k;

            for (int j = 0; j < ds->win_size; j++)
            {
                if (isnan(data[window_offset + j]))
                {
                    is_valid = false;
                    break;
                }
            }
            break;
        }
            // Add other types similarly
        }

        if (is_valid)
            num_valid_forecasts++;
    }

    // Allocate memory for valid forecasts and closest points
    if (num_valid_forecasts > 0)
    {
        valid_forecasts = (int *)malloc(num_valid_forecasts * sizeof(int));
        all_closest_points = (ClosestPoint **)malloc(num_valid_forecasts * sizeof(ClosestPoint *));

        // Second pass: collect valid forecasts
        int valid_idx = 0;
        for (int forecast = ds->start_prediction + thread->thread_id;
             forecast <= ds->end_prediction;
             forecast += ds->num_thread)
        {
            bool is_valid = true;

            // Check if this forecast point is valid (same as above)
            switch (predictor_file->var[n].type)
            {
            case NC_FLOAT:
            {
                float *data = (float *)predictor_file->var[n].data;
                int window_offset = forecast - ds->k;

                for (int j = 0; j < ds->win_size; j++)
                {
                    if (isnan(data[window_offset + j]))
                    {
                        is_valid = false;
                        break;
                    }
                }
                break;
            }
            case NC_DOUBLE:
            {
                double *data = (double *)predictor_file->var[n].data;
                int window_offset = forecast - ds->k;

                for (int j = 0; j < ds->win_size; j++)
                {
                    if (isnan(data[window_offset + j]))
                    {
                        is_valid = false;
                        break;
                    }
                }
                break;
            }
                // Add other types similarly
            }

            if (is_valid)
            {
                valid_forecasts[valid_idx] = forecast;
                all_closest_points[valid_idx] = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));
                valid_idx++;
            }
        }

        // Batch process all valid forecasts
        if (valid_idx > 0)
        {
            // Process in batches for better cache utilization
            int batch_size = 100; // Adjust based on your system's cache size
            for (int batch_start = 0; batch_start < valid_idx; batch_start += batch_size)
            {
                int batch_end = batch_start + batch_size;
                if (batch_end > valid_idx)
                    batch_end = valid_idx;

                for (int i = batch_start; i < batch_end; i++)
                {
                    int found = 0;
                    int forecast = valid_forecasts[i];

                    // Initialize current best distance for early termination
                    ds->current_best_distance = INFINITY;

                    // Search for nearest neighbors using the balanced tree
                    search_closest_points(root, &predictor_file->var[n], ds,
                                          all_closest_points[i], forecast, 0, &found);
                }
            }
        }

        // Process results and recreate data
        for (int i = 0; i < valid_idx; i++)
        {
            recreate_data(predicted_file, ds, all_closest_points[i], f_count, n);
            free(all_closest_points[i]);
            f_count++;
            thread->forecast++;
        }

        // Free allocated memory
        free(valid_forecasts);
        free(all_closest_points);
    }

    // Free the thread's node pool
    free_node_pool(thread_pool);

    pthread_exit(NULL);
}
*/
/*
void parcial_processing_dependent_parallel(NetCDF *file, DataSegment *ds)
{
    NetCDF *predicted_file = &file[0];
    ThreadData thread_data[ds->num_thread];
    pthread_t threads[ds->num_thread];

    ds->predicted_file = &file[0];
    ds->predictor_file = &file[1];

    for (int n = 1; n - 1 < ds->predictor_file->nvars - 13; n++)
    {
        if (ds->predictor_file->var[n].invalid_percentage <= (double)15 &&
            ds->predictor_file->var[n].invalid_percentage != (double)0)
        {
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            switch (ds->predictor_file->var[n].type)
            {
                ALLOCATE_MEMORY_REC_DATA(NC_BYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_CHAR, length);
                ALLOCATE_MEMORY_REC_DATA(NC_SHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_FLOAT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_DOUBLE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UBYTE, length);
                ALLOCATE_MEMORY_REC_DATA(NC_USHORT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT, length);
                ALLOCATE_MEMORY_REC_DATA(NC_INT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_UINT64, length);
                ALLOCATE_MEMORY_REC_DATA(NC_STRING, length);
            }
        }
    }

    for (int t = 0; t < ds->num_thread; t++)
    {
        thread_data[t].thread_id = t;
        thread_data[t].ds = ds;
        thread_data[t].forecast = 0;
        thread_data[t].analog = 0;

        pthread_create(&threads[t], NULL, thread_parcial_processing_dependent, (void *)&thread_data[t]);
    }

    for (int t = 0; t < ds->num_thread; t++)
    {
        pthread_join(threads[t], NULL);
    }

    for (int n = 1; n - 1 < file[0].nvars - 13; n++)
    {
        calculate_rmse(ds->predicted_file, ds, n);
        printf("RMSE: %.3lf\n", ds->predicted_file->var[n].rmse);
    }
}

void *thread_partial_processing_dependent(void *arg)
{
    NetCDF *predicted_file; // Just one
    NetCDF *predictor_file; // One or more
    ThreadData *thread = (ThreadData *)arg;
    DataSegment *ds = (DataSegment *)thread->ds;
    predicted_file = ds->predicted_file;
    predictor_file = ds->predictor_file;

    for (int n = 1; n - 1 < predicted_file->nvars - 13; n++)
    {
        if (predicted_file->var[n].invalid_percentage <= (double)15 &&
            predicted_file->var[n].invalid_percentage != (double)0)
        {
            int f_valid_count = 0;
            int f_id = thread->thread_id;
            int f_count = 0; // Count valid forecast
            int a_count = 0; // Count valid analog
            int count_kdtree = 0;
            int found = 0;
            unsigned int length = (ds->end_prediction - ds->start_prediction);
            bool f_is_valid_window;

            Kdtree *root = NULL;

            /* ---------- Predicted period begins ---------- */
/*
            for (int forecast = ds->start_prediction + thread->thread_id; forecast <= ds->end_prediction; forecast += ds->num_thread)
            {
                int count_test = 0;
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                f_is_valid_window = true;

                for (int j = 0; j < ds->win_size; j++)
                {
                    switch (predictor_file->var[n].type)
                    {
                        F_IFNAN_THREAD(NC_BYTE);
                        F_IFNAN_THREAD(NC_CHAR);
                        F_IFNAN_THREAD(NC_SHORT);
                        F_IFNAN_THREAD(NC_INT);
                        F_IFNAN_THREAD(NC_FLOAT);
                        F_IFNAN_THREAD(NC_DOUBLE);
                        F_IFNAN_THREAD(NC_UBYTE);
                        F_IFNAN_THREAD(NC_USHORT);
                        F_IFNAN_THREAD(NC_UINT);
                        F_IFNAN_THREAD(NC_INT64);
                        F_IFNAN_THREAD(NC_UINT64);
                    }

                    if (!f_is_valid_window)
                        break;
                }

                if (!f_is_valid_window)
                    continue;

                f_valid_count++;

                /* ---------- Training period begins ---------- */
/*
                ClosestPoint *closest = (ClosestPoint *)malloc(ds->num_Na * sizeof(ClosestPoint));

                // search_closest_points(root, &predictor_file->var[n], ds, closest, forecast, 0, &found);
                search_closest_points_super_window(kdtree, predictor_file, ds, closest, forecast, 0, n, &found);

                // printf("------------------------------------------------------------------\n");
                // printf("Posição: %i\n", forecast);
                // for (int i = 0; i < found; i++)
                // {
                //     printf("| P%i D: %.2f ", i, closest[i].distance);
                // }
                // printf("\n");
                // printf("------------------------------------------------------------------\n");

                recreate_data(predicted_file, ds, closest, f_count, n);

                count_kdtree++;
                free(closest);
                f_count++;
            }

            deallocate_kdtree(root);
            printf("f_count: %i\n", thread->forecast);
        }
    }

    pthread_exit(NULL);
}
*/