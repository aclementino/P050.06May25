#ifndef PROCESS_NETCDF
#define PROCESS_NETCDF

#include "structs.h"

#define MONACHE(TYPE)                                                    \
    case TYPE:                                                           \
    {                                                                    \
        for (int x = 0; x < ds->win_size; x++)                           \
        {                                                                \
            double diff =                                                \
                ((TYPE_VAR_##TYPE *)var->data)[(forecast - ds->k) + x] - \
                ((TYPE_VAR_##TYPE *)var->data)[(analog - ds->k) + x];    \
            sum += diff * diff;                                          \
        }                                                                \
    };                                                                   \
    break;

#define MONACHESW(TYPE)                                                            \
    case TYPE:                                                                     \
    {                                                                              \
        for (int x = 0; x < ds->win_size; x++)                                     \
        {                                                                          \
            double diff =                                                          \
                ((TYPE_VAR_##TYPE *)file[f].var[i].data)[(forecast - ds->k) + x] - \
                ((TYPE_VAR_##TYPE *)file[f].var[i].data)[(analog - ds->k) + x];    \
            sum += diff * diff;                                                    \
        }                                                                          \
    };                                                                             \
    break;

/* Validation for forecasts */
#define F_IFNAN(TYPE)                                                                                \
    case TYPE:                                                                                       \
    {                                                                                                \
        /*if (isnan((double)((TYPE_VAR_##TYPE *)predictor_file->var[n].data)                         \
                      [(forecast - ds->k) + j]))                                                     \
        {                                                                                            \
            f_num_is_valid = 0;                                                                      \
            forecast += j; /*Jump to avoid invalid values //                                         \
    }*/                                                                                              \
        if (isnan((double)((TYPE_VAR_##TYPE *)predictor_file->var[n].data)[(forecast - ds->k) + j])) \
        {                                                                                            \
            f_is_valid_window = false;                                                               \
            f_is_valid_last_win = false;                                                             \
            forecast += j; /*Jump to avoid invalid values*/                                          \
            if (flag_break == 1)                                                                     \
                flag_break = -1;                                                                     \
            else                                                                                     \
                continue;                                                                            \
        }                                                                                            \
    }                                                                                                \
    break;

/* Validation for analogs */
#define A_IFNAN(TYPE)                                                                              \
    case TYPE:                                                                                     \
    {                                                                                              \
        if (isnan((double)((TYPE_VAR_##TYPE *)predictor_file->var[n].data)[(analog - ds->k) + j])) \
        {                                                                                          \
            a_is_valid_window = false;                                                             \
            a_is_valid_last_win = false;                                                           \
            analog += j; /*Jump to avoid invalid values*/                                          \
            if (flag_break == 1)                                                                   \
                flag_break = -1;                                                                   \
            else                                                                                   \
                continue;                                                                          \
        }                                                                                          \
    }                                                                                              \
    break;

/* Validation for forecasts - Threads*/
#define F_IFNAN_THREAD(TYPE)                                                                         \
    case TYPE:                                                                                       \
    {                                                                                                \
        if (isnan((double)((TYPE_VAR_##TYPE *)predictor_file->var[n].data)[(forecast - ds->k) + j])) \
        {                                                                                            \
            f_is_valid_window = false;                                                               \
        }                                                                                            \
    }                                                                                                \
    break;

#define ALLOCATE_MEMORY_REC_DATA(TYPE, LENGTH)                                          \
    case TYPE:                                                                          \
        predicted_file->var[n].created_data = malloc(LENGTH * sizeof(TYPE_VAR_##TYPE)); \
        break;

#define REC_DATA(TYPE)                                                                                                                      \
    case TYPE:                                                                                                                              \
    {                                                                                                                                       \
        for (int i = 0; i < ds->num_Na; i++)                                                                                                \
        {                                                                                                                                   \
            if (closest[i].window_index < 0 || closest[i].window_index >= file->dim->len)                                                   \
            {                                                                                                                               \
                /*fprintf(stderr, "Índice inválido em closest[%d].window_index: %d\n", i, closest[i].window_index);*/                       \
                continue;                                                                                                                   \
            }                                                                                                                               \
            if (isnan((double)((TYPE_VAR_##TYPE *)file->var[n].data)[closest[i].window_index]))                                             \
                continue;                                                                                                                   \
            else                                                                                                                            \
            {                                                                                                                               \
                if (!isnan((double)((TYPE_VAR_##TYPE *)file->var[n].data)[closest[i].window_index]))                                        \
                {                                                                                                                           \
                    sum_values += (double)(((TYPE_VAR_##TYPE *)file->var[n].data)[closest[i].window_index]);                                \
                    count++;                                                                                                                \
                } /*printf("| P%i D: %.2lf ",                                                                                               \
                i, (double)((TYPE_VAR_##TYPE *)file->var[n].data)[closest[i].window_index]);*/                                              \
            }                                                                                                                               \
        }                                                                                                                                   \
        ((TYPE_VAR_##TYPE *)file->var[n].created_data)[f_count] = (TYPE_VAR_##TYPE)(sum_values / count);                                    \
        /*printf("--- Predicted: %.2lf | Original: %.2lf\n",                                                                                \
               (double)((TYPE_VAR_##TYPE *)file->var[n].created_data)[indice], (double)((TYPE_VAR_##TYPE *)file->var[n].data)[f_count]); */ \
    }                                                                                                                                       \
    break;

#define CALC_RMSE(TYPE)                                                                        \
    case TYPE:                                                                                 \
        for (int i = ds->start_prediction; i <= ds->end_prediction; i++)                       \
        {                                                                                      \
            if (isnan((double)((TYPE_VAR_##TYPE *)file->var[n].data)[i]))                      \
            {                                                                                  \
                ii++;                                                                          \
                continue;                                                                      \
            }                                                                                  \
            else                                                                               \
            {                                                                                  \
                if (isnan((double)((TYPE_VAR_##TYPE *)file->var[n].created_data)[ii]))         \
                {                                                                              \
                    ii++;                                                                      \
                    continue;                                                                  \
                }                                                                              \
                else                                                                           \
                {                                                                              \
                    double error = (double)((TYPE_VAR_##TYPE *)file->var[n].data)[i] -         \
                                   (double)((TYPE_VAR_##TYPE *)file->var[n].created_data)[ii]; \
                    sum_error += error * error;                                                \
                    ii++;                                                                      \
                    count++;                                                                   \
                }                                                                              \
            }                                                                                  \
        }                                                                                      \
        break;

void processing_data(NetCDF *, DataSegment *, process_func);
void raw_exhaustive_processing_dependent(NetCDF *, DataSegment *);
void exhaustive_processing_independent(NetCDF *, DataSegment *);
void exhaustive_processing_dependent(NetCDF *, DataSegment *);
void partial_processing_dependent(NetCDF *, DataSegment *);
double monache_metric(Variable *, DataSegment *, int, int, int);
double monache_metric_super_window(NetCDF *, DataSegment *, int, int, int);
int compare_closest_point_ord_const(const void *, const void *);
void recreate_data(NetCDF *, DataSegment *, ClosestPoint *, int, int);
/* Threads */
void *thread_exhaustive_processing_dependent(void *);
void exhaustive_processing_dependent_parallel(NetCDF *, DataSegment *);
// void *thread_partial_processing_dependent(void *);
// void partial_processing_dependent_3_threaded(NetCDF *, DataSegment *);

void partial_processing_dependent_2(NetCDF *file, DataSegment *ds);
void partial_processing_dependent_3(NetCDF *file, DataSegment *ds);
#endif